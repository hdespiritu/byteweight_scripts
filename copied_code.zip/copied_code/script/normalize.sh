#!/bin/bash
# This file is to normalize signature file which use semicolon as seperator.
# ./parsearg.sh -i npz -c -s <signature_file> > $folder/$i/normalize/normalize_newline_$j
# e.g. ./parsearg.sh -i npz -c -s $folder/$i/sig_semi/sig_dism_$j > $folder/$i/normalize/normalize_newline_$j
USAGE="Usage: `basename $0` [-i] [-c] [-r] [-j] [-o]";
CALL=false
ORDER=false
JUMP=false
SPLIT=false
# Normalize immediate number
#  Abstract instruction
#  Rules: 1. normalize immediate number as IMM,
#         e.g. movzwl -0x6c(%ebp) %eax
#              call *80000000 -> call *[1-9a-f][0-9a-f]*
#              mov $0xaa %eax
#              mov %gs:0x0, %eax
function normalizeImm {
  if [ -z $IMM ] ; then
    cat
  else
    case "$IMM" in
      all)
        awk '{
          gsub(/-*0x[0-9a-f]+/, "-*0x[0-9a-f]+");
          print $0
        }'
        ;;
      zero) 
        awk '{
          gsub(/-*0x[1-9a-f][0-9a-f]*/, "-*0x[1-9a-f][0-9a-f]*");
          gsub(/0x0+/, "0x0+");
          print $0
        }'
        ;;
      npz) 
        # echo "negtive-positive-zero";
        # positive
        perl -pe "s/(?<! -)0x[1-9a-f][0-9a-f]*/(?<! -)0x[1-9a-f][0-9a-f]*/g" \
        | awk '{
          gsub(/-0x[1-9a-f][0-9a-f]*/, "-0x[1-9a-f][0-9a-f]*");
          gsub(/0x0+/, "0x0+");
          print $0
        }'
        ;;
      pos) 
        # echo "positive-nonpositive";
        # positive
        perl -pe "s/(?<! -)0x[1-9a-f][0-9a-f]*/(?<! -)0x[1-9a-f][0-9a-f]*/g" \
        | awk '{
          # negative and zero
          gsub(/-0x[0-9a-f]+|0x0+/, "-0x[0-9a-f]+|0x0+");
          print $0
        }'
        ;;
      neg) 
        # echo "negative-nonnegative";
        # negative
        awk '{
          gsub(/-0x[1-9a-f][0-9a-f]*/, "-0x[1-9a-f][0-9a-f]*");
          print $0
        }' \
        | perl -pe "s/(?<! -)0x[0-9a-f]+/(?<! -)0x[0-9a-f]+/g"
        ;;
      *) 
        # echo "$USAGE"
        exit 1 ;;
    esac
  fi
}

# call   80491bc <malloc@plt>
# BAP: call   0x000000000804abe0
function normalizeCall {
  if [ "$CALL" = "false" ] ; then
    # echo "call false branch"
    cat
  else
    perl -pe "s/call[q]* +0x[0-9a-f]*(?=;|\-\>|$)/call[q]* +0x[0-9a-f]*/g"
  fi
}

# jmp    *0x806dce0(,%ecx,4)
# jmp    8059b02 <xvasprintf+0x12>
# BAP: jmp    0x000000000804d7b0
function normalizeJmp {
  # echo $JUMP
  if [ "$JUMP" = "false" ] ; then
    cat
  else
    perl -pe  "s/(?<=j[a-z]) +(0x)*[0-9a-f]*(?=;|\-\>|$)/ +(0x)*[0-9a-f]*/g" \
        | perl -pe  "s/(?<=j[a-z][a-z]) +(0x)*[0-9a-f]*(?=;|\-\>|$)/ +(0x)*[0-9a-f]*/g" \
        | perl -pe  "s/(?<=j[a-z][a-z][a-z]) +(0x)*[0-9a-f]*(?=;|\-\>|$)/ +(0x)*[0-9a-f]*/g" \
        | perl -pe  "s/(?<=j[a-z][a-z][a-z][a-z]) +(0x)*[0-9a-f]*(?=;|\-\>|$)/ +(0x)*[0-9a-f]*/g" \
        | perl -pe "s/(?<=j[a-z]) +\\\\\*[0-9a-f]*(?=\\\\)/ +\*[0-9a-f]*/g" \
        | perl -pe "s/(?<=j[a-z][a-z]) +\\\\\*[0-9a-f]*(?=\\\\)/ +\*[0-9a-f]*/g" \
        | perl -pe "s/(?<=j[a-z][a-z][a-z]) +\\\\\*[0-9a-f]*(?=\\\\)/ +\*[0-9a-f]*/g" \
        | perl -pe "s/(?<=j[a-z][a-z][a-z][a-z]) +\\\\\*[0-9a-f]*(?=\\\\)/ +\*[0-9a-f]*/g"
  fi
}

function escape {
  awk '{
    gsub(/\./, "\\.");
    gsub(/\(/, "\\(");
    gsub(/\)/, "\\)");
    gsub(/\+/, "\\+");
    gsub(/\*/, "\\*");
    gsub(/\|/, "\\|");
    gsub(/\?/, "\\?");
    gsub(/\$/, "\\$");
    print $0;
  }'
}

function split {
  if [ "$SPLIT" = "false" ] ; then
    awk '{
      if(index($0, ";")>0){
        gsub(/;/, "\\n^[0-9a-f]+: ");
      };
      print $0
    }'
  else
    awk '{
      if(index($0, ";")>0){
        sub(/;/, "(?=\\n^[0-9a-f]+: ");
        gsub(/;/, "\\n^[0-9a-f]+: ");
        sub(/$/, ")");
      };
      print $0
    }'
  fi
}

function Process {
  escape | normalizeCall | normalizeJmp | normalizeImm
}

while getopts i:r:ocjs OPTION ; do
  case "$OPTION" in
    i) IMM="$OPTARG" ;;
    r) REG="$OPTARG" ;;
    o) ORDER=true ;;
    c) CALL=true ;;
    j) JUMP=true ;;
    s) SPLIT=true ;;
    \?) 
      # echo "$USAGE" ;
      exit 1;;
  esac
done

shift `expr $OPTIND - 1`

#if [ -z "$1" ] ; then
#  echo "ERROR: Input file is not specified."
#  exit 1
#fi
#if [ ! -e "$1" ] ; then
#  echo "ERROR: Input file $1 does not exist."
#  exit 1
#fi
  
cat $1 | Process | grep -v "^$"
