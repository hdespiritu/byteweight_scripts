#!/usr/bin/env python
# Usage : 
#   ./compare.py
#      /data/experiment/tool/ 
#      /data/experiment/gt/ 
#      ToolName 
#      OS
#      csv_file
# TODO: combine diff_lnx and diff_win into one function
import glob
import os
import sys
import csv


cmpDir = sys.argv[1]
gtDir = sys.argv[2]
toolName = sys.argv[3]
OS = sys.argv[4]
if len(sys.argv) >= 6:
    csvFile = sys.argv[5]
else:
    csvFile = ""


c_tp = "tp-%s" % toolName
c_fp = "fp-%s" % toolName
c_fn = "fn-%s" % toolName
c_pre = "pre-%s" % toolName
c_rcl = "rcl-%s" % toolName
orig_column = [c_tp, c_fp, c_fn, c_pre, c_rcl]


def read_from(n):
    res = []
    f = file(n, "r")
    lines = f.readlines()
    for line in lines:
        line = line.strip()
        words = line.split()
        s = int(words[0], 16)
        e = int(words[1], 16)
        res.append((s, e))
    return res


def read_st_from(n):
    res = []
    f = file(n, "r")
    lines = f.readlines()
    for line in lines:
        line = line.strip()
        s = int(line, 16)
        res.append(s)
    return res


# Return : fb, fs, invalid_gt, invalid_fb
# fb and fs are representive [tp, fp, fn]
def diff_lnx(lst, gt):
    lst = sorted(lst)
    gt = sorted(gt)
    tp_fb = 0
    fp_fb = 0
    fn_fb = 0
    tp_fs = 0
    fp_fs = 0
    fn_fs = 0
    invalid_gt = 0
    invalid_fb = 0
    i = 0
    j = 0
    len_lst = len(lst)
    len_gt = len(gt)
    new1 = True
    new2 = True
    while i < len_lst and j < len_gt:
        s1, e1 = lst[i]
        s2, e2 = gt[j]
        compare_fb = True
        if new1 and e1 == 0xffffffffffffffff:
            #print ("invalid %x %x" % (s1, s2))
            invalid_fb += 1
            compare_fb = False
        if new2 and e2 == 0xffffffffffffffff:
            invalid_gt += 1
            compare_fb = False
        
        # Compare start
        if s1 == s2:
            tp_fs += 1
            if compare_fb:
                if e1 <= e2:
                    tp_fb += 1
                # Maybe we have an approximate comparison here
                else:
                    #print ("start correct, but end incorrect %x" % s1)
                    fp_fb += 1
                    fn_fb += 1
            i += 1
            j += 1
            new1 = True
            new2 = True
        # if s1 is less than s2, then s1 is missed, so this is a false positive
        elif s1 < s2:
            #print ("false positive at %x" % s1)
            fp_fs += 1
            fp_fb += 1
            i += 1
            new1 = True
            new2 = False
        # if s1 is larger than s2, then s2 is missed, so this is a false
        # negative
        elif s1 > s2:
            #print ("false negative at %x" % s2)
            fn_fs += 1
            fn_fb += 1
            j += 1
            new1 = False
            new2 = True

    # There more elements in lst left. They are false postives.
    if i < len_lst:
        fp_fs += len_lst - i
        fp_fb += len_lst - i
    elif j < len_gt:
        fn_fs += len_gt - j
        fn_fb += len_gt - j

    # Check
    if fp_fs + tp_fs != len_lst or fn_fs + tp_fs != len_gt:
        print ("total length of compare in function start is incorrect: %d %d %d %d" % (len_lst, len_gt, invalid_fb, invalid_gt))
    
    return [tp_fs, fp_fs, fn_fs], [tp_fb, fp_fb, fn_fb], invalid_gt, invalid_fb


def diff_win(lst, gt_fun, gt_thk):
    lst = sorted(lst)
    gt_fun = sorted(gt_fun)
    tp_fb = 0
    fp_fb = 0
    fn_fb = 0
    tp_fs = 0
    fp_fs = 0
    fn_fs = 0
    invalid_gt = 0
    invalid_fb = 0
    i = 0
    j = 0
    len_lst = len(lst)
    len_gt_fun = len(gt_fun)
    new1 = True
    new2 = True
    while i < len_lst and j < len_gt_fun:
        s1, e1 = lst[i]
        s2, e2 = gt_fun[j]
        compare_fb = True
        if new1 and e1 == 0xffffffffffffffff:
            #print ("invalid %x %x" % (s1, s2))
            invalid_fb += 1
            compare_fb = False
        if new2 and e2 == 0xffffffffffffffff:
            invalid_gt += 1
            compare_fb = False
        
        # Compare start
        if s1 == s2:
            tp_fs += 1
            if compare_fb:
                if e1 <= e2:
                    tp_fb += 1
                # Maybe we have an approximate comparison here
                else:
                    #print ("start correct, but end incorrect %x" % s1)
                    fp_fb += 1
                    fn_fb += 1
            i += 1
            j += 1
            new1 = True
            new2 = True
        # if s1 is less than s2, then s1 is missed, so this is a false positive
        elif s1 < s2:
            #print ("false positive at %x" % s1)
            # in Windows, such false positive may due to additional function
            # identification for thunk. If so, this is not a real false
            # positive.
            if not (s1 in gt_thk):
                fp_fs += 1
                fp_fb += 1
            i += 1
            new1 = True
            new2 = False
        # if s1 is larger than s2, then s2 is missed, so this is a false
        # negative
        elif s1 > s2:
            #print ("false negative at %x" % s2)
            fn_fs += 1
            fn_fb += 1
            j += 1
            new1 = False
            new2 = True

    # If there more elements in lst left, they are false postives.
    if i < len_lst:
        for s1 in lst[i:]:
            if not (s1[0] in gt_thk):
                fp_fs += 1
                fp_fb += 1
    # If there more elements in gt_fun left, they are false negatives.
    elif j < len_gt_fun:
        fn_fs += len_gt_fun - j
        fn_fb += len_gt_fun - j

    # Check
    if fp_fs + tp_fs != len_lst or fn_fs + tp_fs != len_gt_fun:
        print ("total length of compare in function start is incorrect: %d %d %d %d" % (len_lst, len_gt_fun, invalid_fb, invalid_gt))
    
    return [tp_fs, fp_fs, fn_fs], [tp_fb, fp_fb, fn_fb], invalid_gt, invalid_fb


def work(name, nums, item):
    tp = nums[0]
    fp = nums[1]
    fn = nums[2]
    # print ("tp: %d, fp: %d, fn: %d" % (tp, fp, fn))
    if tp + fp > 0:
        nums.append(tp / float(tp + fp))
    else:
        nums.append(float('nan'))
    if tp + fn > 0:
        nums.append(tp / float(tp + fn))
    else:
        nums.append(float('nan'))
    columns = map(lambda x : "%s-%s" % (name, x), orig_column)
    
    for i in range(5):
        item[columns[i]] = nums[i]


def extract_arch(b):
    return b.split("_")[2]

# Return : a list of dict
# e.g. [{'num' : 0, 'name' : 'ed'}]
# We will have [{'binary': 'gcc_binutils_32_O3_size', 
#                 'OS' : 'Linux',
#                 'Architecture' : 32
#                 'tp' : xxx
#                 'fp' : xxx
#                 'fn' : xxx
#                 'Invalid GT' : xxx
#                 'Invalid Boundary' : xxx
#                },
#               ]
def compare(cmpDir, gtDir, toolName, OS):
    d = []
    bin_list = []
    if OS == "Linux":
        for f in glob.glob("%s/*" % gtDir):
            bsnm = os.path.basename(f)
            bin_list.append(bsnm)
    elif OS == "Windows":
        for f in glob.glob("%s/function/*" % gtDir):
            bsnm = os.path.basename(f)
            bin_list.append(bsnm)
    
    column = []
    for b in bin_list:
        # Read in file to be compared and ground truth 
        cmp = "%s/%s" % (cmpDir, b)
        if OS == "Linux":
            gt = "%s/%s" % (gtDir, b)
            try:
                list_cmp = read_from(cmp)
            except Exception:
                print "WARNING: file %s does not exist" % cmp
                continue
            list_gt = read_from(gt)
            
            fs, fb, invalid_gt, invalid_fb = diff_lnx(list_cmp, list_gt)
        
        elif OS == "Windows":
            gt_fun = "%s/function/%s" % (gtDir, b)
            gt_thk = "%s/thunk/%s" % (gtDir, b)
            try:
                list_cmp = read_from(cmp)
            except Exception:
                print "WARNING: file %s does not exist" % cmp
                continue
            list_gt_fun = read_from(gt_fun)
            list_gt_thk = read_st_from(gt_thk)
            # print list_gt_fun
            # print list_gt_thk
            fs, fb, invalid_gt, invalid_fb = diff_win(list_cmp,
                    list_gt_fun, list_gt_thk)
            # print fs, fb, invalid_gt, invalid_fb
        else:
            print "OS is not able to be recognized"
            raise
            
        item = {}
        item["binary"] = b
        item["os"] = OS
        item["bit"] = extract_arch(b)
        item["nofb-gt"] = invalid_gt
        item["nofb-%s" % toolName] = invalid_fb
        work("func-st", fs, item)
        work("func-bd", fb, item)
        tp = fb[0]
        fp = fb[1]
        fn = fb[2]
        if tp + fp > 0:
            pre = tp / float(tp + fp)
        else:
            pre = float('nan')
        if tp + fn > 0:
            rcl = tp / float(tp + fn)
        else:
            rcl = float('nan')

        #print item
        
        d.append(item)
        column = item.keys()

    if csvFile <> "":
        output = open(csvFile, "wb")
    else:
        output = sys.stdout
    csvwriter = csv.DictWriter(output, delimiter=",", fieldnames=column)
    csvwriter.writerow(dict((fn, fn) for fn in column))
    for row in d:
        csvwriter.writerow(row)
    output.close()
    return d, column


if __name__ == "__main__":
    compare(cmpDir, gtDir, toolName, OS)
