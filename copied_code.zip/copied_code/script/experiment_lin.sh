#!/bin/bash
# prepare the model for both training and testing
dir=`realpath $1`

# k: number of fold
k=10

# $1: list of binaries
function Separate {
    list=($(cat $dir/list))
    echo "list: ${list[2]}"
    tot=${#list[*]}
    least=`expr $tot / $k`
    rest=`expr $tot - $least \* $k`
    echo "tot : $tot"
    echo "rest : $rest"
    for i in $(seq 1 $rest)
    do
        arr[$i]=`expr $least + 1`
    done
    for i in $(seq `expr $rest + 1` $k)
    do
        arr[$i]=$least
    done

    echo ${arr[@]}

    #initialization
    for i in $(seq 1 $k)
    do
        mkdir -pv $dir/$i
        mkdir -pv $dir/$i/test_binary
        mkdir -pv $dir/$i/test_addr_instr
        mkdir -pv $dir/$i/test_norm_addr_instr
        mkdir -pv $dir/$i/test_gt
        mkdir -pv $dir/$i/train_sig
        mkdir -pv $dir/$i/train_instr_stat
    done

    path=`realpath $dir`
    cur=0
    for i in $(seq 1 $k)
    do
        echo $i
        for j in $(seq 1 ${arr[$i]})
        do
            index=`expr $cur + $j - 1`
            echo "    $index"
            b=${list[$index]}
            echo $b
            for l in $(seq 1 $k)
            do
                if [ $l == $i ]
                then
                    ln -s $path/test_addr_instr/$b $path/$l/test_addr_instr/$b
                    ln -s $path/test_norm_addr_instr/$b $path/$l/test_norm_addr_instr/$b
                    ln -s $path/gt/$b $path/$l/test_gt/$b
                    ln -s $path/binary/$b $path/$l/test_binary/$b
                else
                    ln -s $path/train_sig/$b $path/$l/train_sig/$b
                    ln -s $path/train_instr_stat/$b $path/$l/train_instr_stat/$b
                fi
            done
        done
        cur=`expr $cur + ${arr[$i]}`
    done
}

function Preprocess {
    for f in $dir/binary/*
    do
        b=`basename $f`
        
        if [ ! -s $dir/train_instr_stat/$b ] || 
            [ ! -s $dir/test_addr_instr/$b ] ||
            [ ! -s $dir/gt/$b ]
        then
            # Generate gt, test dism, and instr statistics
            echo "../bap/utils/bin2instr -f $f\
                -o-train $dir/train_instr_stat/$b\
                -o-test $dir/test_addr_instr/$b\
                -o-prf $dir/performance.csv"
            ../bap/utils/bin2instr -f $f\
                -o-train $dir/train_instr_stat/$b\
                -o-test $dir/test_addr_instr/$b\
                -o-prf $dir/performance.csv
        fi
    
        # Normalize signatures
        if [ ! -d $dir/train_norm_instr_stat ]
        then
          mkdir $dir/train_norm_instr_stat
        fi
        if [ ! -s $dir/train_norm_instr_stat/$b ]
        then
            echo "./normalize.sh -i npz -c -j $dir/train_instr_stat/$b > $dir/train_norm_instr_stat/$b"
            t_norm=`(time -p ./normalize.sh -i npz -c -j $dir/train_instr_stat/$b \
                > $dir/train_norm_instr_stat/$b) 2>&1 | grep "real" | awk '{print $2}'`
            echo "train, normalization, $b, $t_norm" >> $dir/performance.csv
        fi

        # Clean train_norm_instr_stat file.
        if [ ! -s $dir/train_sig/$b ]
        then
            echo "../bap/utils/train_norm_stat -f $dir/train_norm_instr_stat/$b -o $dir/train_sig/$b"
            t_clean=`(time -p ../bap/utils/train_norm_stat -f \
            $dir/train_norm_instr_stat/$b -o $dir/train_sig/$b) 2>&1 \
            | grep "real" | awk '{print $2}'`
            echo "train, norm_clean, $b, $t_clean" >> $dir/performance.csv
        fi
       
        # Test Preparation
        if [ ! -d $dir/test_norm_addr_instr ]
        then
            mkdir $dir/test_norm_addr_instr
        fi
        if [ ! -s $dir/test_norm_addr_instr/$b ]
        then
            echo "./normalize.sh -i npz -c -j $dir/test_addr_instr/$b > $dir/test_norm_addr_instr/$b"
            t_normt=`(time -p ./normalize.sh -i npz -c -j $dir/test_addr_instr/$b > \
                $dir/test_norm_addr_instr/$b) 2>&1 | grep "real" | awk '{print $2}'`
            echo "test, normalization, $b, $t_normt" >> $dir/performance.csv
        fi
    done 
}

function Test {
    echo "============================Testing======================"
    for i in $(seq 1 $k)
    do
        if [ -s $dir/$i/pruned_trie ]
        then
            echo "../bap/utils/test.dbg -i-dir $dir/$i/test_norm_addr_instr/ -bin-dir \
            	$dir/$i/test_binary -sig-file $dir/$i/pruned_trie -o-dir $dir/$i/test_score \
            	-fb-dir $dir/$i/test_fb -o-prf $dir/$i/performance.csv &"   
            ../bap/utils/test.dbg -i-dir $dir/$i/test_norm_addr_instr/ -bin-dir \
            	$dir/$i/test_binary -sig-file $dir/$i/pruned_trie -o-dir $dir/$i/test_score \
            	-fb-dir $dir/$i/test_fb -o-prf $dir/$i/performance.csv \
            	>> $dir/$i/log &
        else
            echo "../bap/utils/test.dbg -i-dir $dir/$i/test_norm_addr_instr/ -bin-dir \
            	$dir/$i/test_binary -sig-dir $dir/$i/train_sig -o-dir $dir/$i/test_score \
            	-fb-dir $dir/$i/test_fb -o-prf $dir/$i/performance.csv &"   
            ../bap/utils/test.dbg -i-dir $dir/$i/test_norm_addr_instr/ -bin-dir \
            	$dir/$i/test_binary -sig-dir $dir/$i/train_sig -o-dir $dir/$i/test_score \
            	-fb-dir $dir/$i/test_fb -o-prf $dir/$i/performance.csv \
            	>> $dir/$i/log &
        fi
    done
}

function RFCR {
    echo "============================RFCR========================="
    for i in $(seq 1 $k)
    do
        echo "../bap/utils/rfcr.dbg -bin-dir $dir/$i/test_binary/ \
            -fb-dir $dir/$i/test_fb/ \
            -fb-call-dir $dir/$i/test_fb_rfcr/ \
            -o-prf $dir/$i/performance.csv \
            >> $dir/$i/log_rfcr &"
        ../bap/utils/rfcr.dbg -bin-dir $dir/$i/test_binary/ \
            -fb-dir $dir/$i/test_fb/ \
	    -fb-call-dir $dir/$i/test_fb_rfcr/ \
            -o-prf $dir/$i/performance.csv \
            >> $dir/$i/log_rfcr &
    done
}

# === Main ===

echo "phase, subphase, binary, time" >> $dir/performance.csv
Preprocess

if [ ! -s $dir/list ]
then
    list=($(ls $dir/binary | xargs shuf -e))
    echo ${list[@]} > $dir/list
fi
Separate

Test
while pgrep test.dbg > /dev/null
do
    sleep 1
done
mkdir $dir/test_fb
cp $dir/*/test_fb/* $dir/test_fb/.

RFCR
while pgrep rfcr.dbg > /dev/null
do
    sleep 1
done

mkdir $dir/test_fb_rfcr
cp $dir/*/test_fb_rfcr/* $dir/test_fb_rfcr/.
