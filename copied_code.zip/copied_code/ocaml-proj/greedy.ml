module D = Debug.Make(struct let name = "Greedy" and default=`NoDebug end)
open D

(* This is a naive comparison *)
let compare (addr_s1,addr_e1,scr1,instr1) (addr_s2,addr_e2,scr2,instr2) =
  (* compare the score : from high to low *)
  let comp = 0 - (compare scr1 scr2) in
  (* compare the start address : from low to high *)
  let comp =
    if comp = 0 then
      Big_int_Z.compare_big_int addr_s1 addr_s2
    else comp
  in
  (* compare the length of instruction : from short to long *)
  let comp = 
    if comp = 0 then
      let len1 = List.length instr1 in
      let len2 = List.length instr2 in
      compare len1 len2
    else comp
  in
  (* compare the length of matched signature : from long to short *)
  let comp =
    if comp = 0 then
      let interval1 = Big_int_Z.sub_big_int addr_e1 addr_s1 in
      let interval2 = Big_int_Z.sub_big_int addr_e2 addr_s2 in
      0 - (Big_int_Z.compare_big_int interval1 interval2)
    else comp
  in
  comp

let overlap (addr_s1,_,_,instr1) (addr_s2,_,_,instr2) =
  (* check if element in instr1 exists in instr2*)
  (* List.fold_left (fun flag elt -> flag || (List.mem elt instr2)) false instr1 *)
  List.fold_left (fun flag elt -> 
    if List.mem elt instr2 then dprintf "%lx is conflict with %lx" (Big_int_Z.int32_of_big_int addr_s1) (Big_int_Z.int32_of_big_int addr_s2);
    flag || (List.mem elt instr2)
  ) false instr1

let conflict elt elts =
  List.fold_left (fun flag elt' -> flag || (overlap elt elt')) false elts

let rec pick res = function
  | hd :: others -> ( match hd with
    | (addr_s, _, _, _) -> 
      dprintf "%lx" (Big_int_Z.int32_of_big_int addr_s);
      if conflict hd res then (
         (* if Big_int_Z.eq_big_int addr_s (Big_int_Z.big_int_of_int 0x804b044) then( 
              dprintf "conflict";
              let _ = input_char stdin in ()
        ); *)
        pick res others
      )
      else ( 
        match hd with
          | (_, _, scr, _) -> if scr > 0.5 then pick (hd::res) others else pick res others
      )
  )
  | [] -> res 

let map_to_interval res_list =
  List.map (fun (addr_s, _, _, _) -> addr_s) res_list

let greedy model_list =
  let sort_list = List.fast_sort compare model_list in
  let res_list = pick [] sort_list in
  let st_list = map_to_interval res_list in
  let sorted_st_list = List.fast_sort Big_int_Z.compare_big_int st_list in
  sorted_st_list
