type dism =
  | VSA
  | RD

let print_res oc start_list binname =
  List.iter (fun addr ->
    Printf.fprintf oc "%s %lx\n%!" binname (Big_int_Z.int32_of_big_int addr)
  ) start_list

let print_model oc model_list binname =
  List.iter (fun (s, e, scr, addrs) ->
    Printf.fprintf oc "%s %lx %lx %f"
      binname
      (Big_int_Z.int32_of_big_int s)
      (Big_int_Z.int32_of_big_int e)
      scr;
    List.iter (fun a -> 
      Printf.fprintf oc " %lx" (Big_int_Z.int32_of_big_int a)
    ) addrs;
    Printf.fprintf oc "\n%!"
  ) model_list

(* extract_addr_dism : Ast.stmt list -> (addr * instr (string)) option *)
let rec extract_addr_dism = function
  | h :: tl -> 
    (
    match h with
    | Ast.Label (Type.Addr addr, attrs) -> 
      let asm_list = List.filter (fun a ->
        match a with
        | Type.Asm s -> true
        | _ -> false
      ) attrs
      in
      if asm_list = [] then extract_addr_dism tl
      else if List.length asm_list > 1 then failwith "multiple disassembly in one instruction"
      else
        let asm = List.hd asm_list in
        (match asm with
        | Type.Asm s -> Some (addr, s)
        | _ -> failwith "Not Impossible: the other types should be filtered out")
    | _ -> extract_addr_dism tl
    )
  | [] -> None


(* get_dism : Ast.asmprogram -> addr -> int -> fun -> addr -> instr(string) list*)
let get_dism p addr count ?(invalid = fun x -> false) bounce =
  let disassem_one p a =
    let addr_dism_opt, n =
      try(
        let prog, n = Asmir.asm_addr_to_bap p a in
        let open Ast in
        extract_addr_dism prog, n
      )
      with _ -> Some(a, "bad"), Big_int_convenience.bi0
    in 
    let dism = match addr_dism_opt with
      | Some (_, d) -> d
      | None ->
          failwith (Printf.sprintf "Disassembly is not found in addr %s"
          (Big_int_convenience.(~%a)))
    in
    dism, n
  in
  let bad_dism s =
    try (
      (* bad dism can be : bad or (bad) or .byte *)
      let _ = Str.search_forward (Str.regexp "bad\\|byte") s 0 
      in
      true
    )
    with Not_found -> false
  in
  let rec next addr count tmp =
    if count = 0 then List.rev tmp
    else if Big_int_convenience.(>=%) addr bounce then List.rev tmp
    else if invalid addr then List.rev tmp 
    else
      let dism, n = disassem_one p addr in
      if bad_dism dism then List.rev tmp
      else
        (* let dism_strip = Str.replace_first (Str.regexp " *#.*") "" dism in *)
        (* remove comment and redundant blanks *)
        let dism_strip = Str.replace_first 
          (Str.regexp "\\( *\\| *#.*\\)$") "" dism 
        in
        let dism_fmt_jmp =
          if Str.string_match (Str.regexp "[jJ][A-Za-z]+ ") dism_strip 0 = true then
            Str.replace_first (Str.regexp "0x") "" dism_strip
          else dism_strip
        in
        (* if String.length dism > String.length dism_strip then
          Printf.printf "%s -> %s\n" dism dism_strip; *)
        next n (count - 1) (dism_fmt_jmp :: tmp)
  in
  next addr count []

(* TODO: change function name to get_func_addrs.
 * Here instr means the ADDRESS of instr *)
let get_func_instr p addr opt =
  try (
    let cfg = match opt with
    | RD -> 
        Util.timeout ~secs:10 ~f:(Asmir_disasm.recursive_descent_at p) ~x: addr
    | VSA ->
        Util.timeout ~secs:30 ~f:(Asmir_disasm.vsa_at p) ~x: addr
    in
    let instrs = Cfg.AST.G.fold_vertex (fun v addrs ->
      let stmts = Cfg.AST.get_stmts cfg v in
      let addr_dism_opt = extract_addr_dism stmts in
      match addr_dism_opt with
      | Some (a, _) -> a::addrs
      | None -> addrs
    ) cfg []
    in Some (List.fast_sort Big_int_Z.compare_big_int instrs)
  ) with _ -> None

(* get_func_addrs_callees : Asmir.asmprogram -> Addr -> Func_boundary_util.dism
 * -> (Addr list * Addr list ) option
 *)
let get_func_addrs_callees p addr opt =                 
  let check_callee s = 
    try (
      let words = Str.split (Str.regexp " ") s in
      let non_empty_words = List.filter (fun word -> word <> "") words in
      match non_empty_words with
      | mnenomic :: addr :: [] when Str.string_match (Str.regexp "call*") mnenomic 0 ->
          Printf.printf "Disassembly %s is call\n%!" s;
          let formatted_addr = 
            if Str.string_match (Str.regexp "0x*") addr 0 then addr
            else Printf.sprintf "0x%s" addr
          in
          Printf.printf "Callee: %s\n%!" formatted_addr;
          Some (Big_int_Z.big_int_of_string formatted_addr)
      | _ -> None
    )
    with _ -> None
  in
  try (
    let cfg = match opt with
      | RD -> 
        Util.timeout ~secs:10 ~f:(Asmir_disasm.recursive_descent_at p) ~x: addr
      | VSA ->
        Util.timeout ~secs:30 ~f:(Asmir_disasm.vsa_at p) ~x: addr
    in
    let addrs_all, addrs_call =
      Cfg.AST.G.fold_vertex (fun v (t_addrs_all, t_addrs_call) ->
        let addr_dism_opt =
          let stmts = Cfg.AST.get_stmts cfg v in
          extract_addr_dism stmts
        in
        match addr_dism_opt with
        | Some (a, dism) -> 
           (match check_callee dism with
             | None -> a :: t_addrs_all, t_addrs_call
             | Some callee -> a :: t_addrs_all, callee :: t_addrs_call
          )
        | None -> t_addrs_all, t_addrs_call
      ) cfg ([],[])
    in
    Printf.printf "Callees from address %Lx :"
    (Big_int_convenience.addr_to_int64 addr);
    List.iter (fun a -> 
      Printf.printf "%Lx " (Big_int_convenience.addr_to_int64 a)
    ) addrs_call;
    Printf.printf "\n%!";
    
    (List.fast_sort Big_int_Z.compare_big_int addrs_all),
      (List.fast_sort Big_int_Z.compare_big_int addrs_call)
  ) with _ -> [], []
