module D = Debug.Make(struct let name = "Cfg_index" and default = `Debug end)
open D



(* Write a functor from Cfg.AST to inputi*)
module MakeSetInput (G : Cfg.CFG) : Set.OrderedType with type t = G.G.V.t = 
struct
  type t = G.G.V.t
  let compare v1 v2 = String.compare (G.v2s v1 ) (G.v2s v2)
end

module CFGVertex = MakeSetInput(Cfg.AST)
module CFGVSet = Set.Make(CFGVertex)

let dprint_set s hint =
    dprintf "%s" hint;
    CFGVSet.iter(fun elt ->
      dprintf " %s" (Cfg.AST.v2s elt);
    ) s;
    dprintf "\n"


let vertex_contain_keyword v key cfg =
  let stmts = Cfg.AST.get_stmts cfg v in
  List.exists (function
    | Ast.Label (label, attrs) ->
        List.exists (function
          | Type.Asm s -> BatString.exists s key
          | _ -> false
        ) attrs
    | _ -> false
  ) stmts

let find_vertex_by_keyword cfg key =
  let vertex_list = Cfg.AST.G.fold_vertex (fun v l ->
    if vertex_contain_keyword v key cfg then v::l else l
  ) cfg []
  in
  match vertex_list with
  | v :: [] -> v
  | _ -> 
    Printf.printf "Error: contain multiple or zero vertex";
    Cfg.AST.find_vertex cfg Cfg.BB_Error


let copy_vertex v srcg dstg =
  let g = Cfg.AST.add_vertex dstg v in
  let stmts = Cfg.AST.get_stmts srcg v in
  let g = Cfg.AST.set_stmts g v stmts in
  g

let append_pred v g cfg =
  Cfg.AST.G.fold_pred_e (fun pred_e g ->
    let pred = Cfg.AST.G.E.dst pred_e in
    let g = copy_vertex pred cfg g in
    Cfg.AST.add_edge_e g pred_e
  ) cfg v g

let rec bfs_pred vs g l cfg =
  if l = 0 then g
  else (
    let nextg = 
      List.fold_left (fun nextg v ->
        append_pred v nextg cfg
      ) g vs
    in 
    let nextvs = 
      List.fold_left (fun l v ->
        (Cfg.AST.G.pred cfg v) @ l
      ) [] vs
    in bfs_pred nextvs nextg (l-1) cfg
  )


(* This function is to get the vertices that are exact l-predecessor of v*)
let rec get_pred_vs vs cfg l =
  if l = 0 then (vs, 0)
  else (
    let new_vs = CFGVSet.empty in
    let new_vs = CFGVSet.fold (fun v set ->
      let preds = Cfg.AST.G.pred cfg v in
      let added_set_per_v = List.fold_left (fun set pred ->
        if (Cfg.AST.G.V.label pred != Cfg.BB_Indirect) then
          CFGVSet.add pred set
        else (
          set
        )
      ) new_vs preds
      in
      CFGVSet.union added_set_per_v set
    ) vs new_vs
    in
    if (CFGVSet.is_empty new_vs) then (vs, l)
    else
      get_pred_vs new_vs cfg (l - 1)
  )

(* This function is to get all the vertices from the l-predecessors to v*)
let rec bfs_succ vs vall cfg l =
  if l = 0 then vall
  else (
    let new_vs = CFGVSet.empty in
    let new_vs = CFGVSet.fold (fun v set ->
      dprint_set set "current new_vs";
      let succs = Cfg.AST.G.succ cfg v in
      let added_set_per_v = 
        List.fold_left (fun set succ ->
          if (Cfg.AST.G.V.label succ != Cfg.BB_Indirect) then (
              dprintf "add %s to set \n" (Cfg.AST.v2s succ);
              CFGVSet.add succ set
          )
          else (
            set
          )
      ) new_vs succs
      in
      CFGVSet.union added_set_per_v set
    ) vs new_vs
    in
    let new_vall = CFGVSet.union vall new_vs in
    bfs_succ new_vs new_vall cfg (l - 1)
  )

let subvertices v cfg pred_l succ_l =
  (* Initial Vertices Set*)
  let vset = CFGVSet.empty in
  let vset = CFGVSet.add v vset in
  (* get set including the l-predecessors*)
  let topvset, finallevel = get_pred_vs vset cfg pred_l in
  let all = bfs_succ topvset topvset cfg (pred_l-finallevel+succ_l) in
  all


let copy_edge srcg dstg =
  Cfg.AST.G.fold_edges_e (fun e dstg ->
    let srcv = Cfg.AST.G.E.src e in
    let dstv = Cfg.AST.G.E.dst e in
    if (Cfg.AST.G.mem_vertex dstg srcv) && (Cfg.AST.G.mem_vertex dstg dstv)
    then Cfg.AST.add_edge_e dstg e
    else dstg
  ) srcg dstg

let subgraph v cfg =
  let subg = Cfg.AST.empty () in
  match Cfg.AST.G.V.label v with
    | Cfg.BB_Error -> subg
    | _ ->
      let subvset = subvertices v cfg 5 5 in
      let subg = CFGVSet.fold (fun v subg -> 
        copy_vertex v cfg subg) subvset subg 
      in
      let subg = copy_edge cfg subg
      (* let subg = Cfg.AST.G.fold_succ_e (fun succ_e g ->
        let succ = Cfg.AST.G.E.dst succ_e in
        let g = copy_vertex succ cfg g in
        Cfg.AST.add_edge_e g succ_e
      ) cfg v subg
      in
      let subg = Cfg.AST.G.fold_pred_e (fun pred_e g ->
        let pred = Cfg.AST.G.E.dst pred_e in
        let g = copy_vertex pred cfg g in
        Cfg.AST.add_edge_e g pred_e
      ) cfg v subg *)
      in
      subg

let output_graph g = 
  Cfg_pp.AstStmtsDot.output_graph stdout g
