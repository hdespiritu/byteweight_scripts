module D = Debug.Make(struct let name = "Get_input" and default=`NoDebug end)
open D

exception File_format_error
type instr = string
type addr = Type.addr

let str_to_addr str = 
  let addr = Printf.sprintf "0x%s" (String.trim str) in
  Big_int_Z.big_int_of_string addr

(* to_assem : string -> addr * instr
 * to_assem : line
 * to_assem : convert a line to assem, which is a tuple of address and
 * instruction 
 *)
let to_assem line =
  let words = Str.split (Str.regexp ": ") line in
  match words with
    | hd :: tl :: [] -> 
        let addr = str_to_addr hd in
        addr, tl
    | _ -> (
      Printf.printf "line %s is in wrong format" line;
      raise File_format_error
    )

(* to_pattern : string -> instr list * float
 * to_pattern : line
 * to_pattern : convert a line to signature and its score (the 'utility')
 * push   %edi\n^[0-9a-f]+: push  %ebp->1 
 *)
let to_pattern line =
  (* let convert s = 
    let sout = Str.global_replace (Str.regexp "(\\?<! -)") "" s in
    let sout = Str.global_replace (Str.regexp "\\\\(") "(" sout in
    let sout = Str.global_replace (Str.regexp "\\\\)") ")" sout in
    dprintf "%s --> %s\n" s sout;
    sout
  in *)
  let words = Str.split (Str.regexp "->") line in
  match words with
    | hd :: tl :: [] ->(
        (* dprintf "%s\n" tl; *)
        let score = float_of_string tl in
        (* let sigs = Str.split (Str.regexp "\\\\n\\^\\[0-9a-f\\]\\+: ") hd in *)
        let sigs = Str.split (Str.regexp ";") hd in
        (* let sigs = List.map convert sigs in *)
        (* List.iter (dprintf "%s\n") sigs; *)
        sigs, score
    )
    | _ -> (
      Printf.printf "line %s is in wrong format\n" line;
      raise File_format_error
    )

(* to_pattern2 : string -> instr list * float
 * to_pattern2 : line
 * to_pattern2 : convert a line to signature and its score (the 'utility')
 * push   %edi;push  %ebp->1 2 
 *)
let to_pattern2 line =
  (* let convert s = 
    let sout = Str.global_replace (Str.regexp "(\\?<! -)") "" s in
    let sout = Str.global_replace (Str.regexp "\\\\(") "(" sout in
    let sout = Str.global_replace (Str.regexp "\\\\)") ")" sout in
    dprintf "%s --> %s\n" s sout;
    sout
  in *)
  let calc_p str =
    try (
      let words = Str.split (Str.regexp " ") str in
      match words with
      | [s; n_s] -> float(int_of_string s) /.
        (float(int_of_string n_s) +. float(int_of_string s))
      | _ -> failwith "File format error"
    )
    with _ -> failwith "File format error"
  in
  let words = Str.split (Str.regexp "->") line in
  match words with
    | hd :: tl :: [] ->(
        (* dprintf "%s\n" tl; *)
        let score = calc_p tl in
        let sigs = Str.split (Str.regexp ";") hd in
        (* let sigs = List.map convert sigs in *)
        (* List.iter (dprintf "%s\n") sigs; *)
        sigs, score
    )
    | _ -> (
      Printf.printf "line %s is in wrong format\n" line;
      raise File_format_error
    )

let simplify s = 
  let s_simp = 
    let s_nonneg = Str.global_replace (Str.regexp "(\\?<! -)") "" s in
    let s_lft_prn = Str.global_replace (Str.regexp "\\\\(") "(" s_nonneg in
    let s_rght_prn = Str.global_replace (Str.regexp "\\\\)") ")" s_lft_prn in
    s_rght_prn
  in
  dprintf "%s --> %s\n" s s_simp;
  s_simp

(* to_instr_p_n : string -> instr list * (int * int)
 * to_instr_p_n : line
 * to_instr_p_n : convert a line to signature and its positive and negative
 * occurence
 * push   %edi;push  %ebp->1 2 
 *)
let to_instr_p_n line =
  (* let convert s = 
    let sout = Str.global_replace (Str.regexp "(\\?<! -)") "" s in
    let sout = Str.global_replace (Str.regexp "\\\\(") "(" sout in
    let sout = Str.global_replace (Str.regexp "\\\\)") ")" sout in
    dprintf "%s1 --> %s\n" s sout;
    sout
  in *)
  let calc_p str =
    try (
      let words = Str.split (Str.regexp " ") str in
      match words with
      | [p; n] -> (int_of_string p), (int_of_string n)
      | _ -> failwith "File format error"
    )
    with _ -> failwith "File format error"
  in
  let words = Str.split (Str.regexp "->") line in
  match words with
    | hd :: tl :: [] ->(
        (* dprintf "%s\n" tl; *)
        let p, n = calc_p tl in
        let sigs = Str.split (Str.regexp ";") hd in
        (* let sigs = List.map convert sigs in *)
        List.iter (dprintf "%s") sigs;
        dprintf "%s -> %d %d\n" hd p n;
        sigs, (p, n)
    )
    | _ -> (
      Printf.printf "line %s is in wrong format\n" line;
      raise File_format_error
    )

(* to_model : string -> string * addr * addr * float * addr list *)
let to_model line =
  let words = Str.split (Str.regexp " ") line in
  match words with
  | name :: addr_s :: addr_e_of_sig :: score :: others ->
      let addr_s = str_to_addr addr_s in
      let addr_e_of_sig = str_to_addr addr_e_of_sig in
      let score = float_of_string score in
      let others = List.map str_to_addr others in
      (name, addr_s, addr_e_of_sig, score, others)
  | _ ->
    Printf.printf "line %s is in wrong format\n" line;
    raise File_format_error

(* to_func_bound : string -> string * addr * addr *)
(* to_func_bound line
 * convert a line to address tuple which represents start and end address of a
 * function
 *)
let to_func_bound line =
  let words = Str.split (Str.regexp " ") line in
  match words with
  | name :: s_addr :: e_addr :: [] ->
      name, (str_to_addr s_addr), (str_to_addr e_addr)
  | _ -> failwith "file format error"

(* to_fb : string -> addr * addr *)
(* to_fb line
 * convert a line to a tuple of addresses representing start and end address
 *)
let to_fb line =
  let words = Str.split (Str.regexp " ") line in
  match words with
  | s_addr :: e_addr :: [] ->
      (str_to_addr s_addr), (str_to_addr e_addr)
  | _ -> failwith "To_fb: file format error"

(* to_instr_stat : string -> instr(string) * int * int *)
let to_instr_stat line =
  let words = Str.split (Str.regexp "->") line in
  match words with
  | [instr ; others] ->
      let ws = Str.split (Str.regexp " ") others in
      (match ws with
        | [s; n_s] -> 
            (* let index = try Some(String.index n_s ')') with Not_found -> None in
            (match index with
            | Some i ->
                let n_s = String.sub n_s 0 i in
                let instr = Printf.sprintf "%s)" instr in
                instr, (int_of_string s), (int_of_string n_s)
            | None -> 
              instr, (int_of_string s), (int_of_string n_s)
            ) *)
            instr, (int_of_string s), (int_of_string n_s)
        | _ -> failwith (Printf.sprintf "file format error in %s" line)
      )
  | _ -> failwith (Printf.sprintf "file format error in %s" line)

(* to_addr_instr_cfg : string -> addr * instr list * addr list *)
let to_addr_instr_cfg line =
  let words = Str.split (Str.regexp "->") line in
  (* List.iter (fun w -> Printf.printf "%s\n" w) words; *)
  let addr, instr =
    match words with
    | [addr; instr; _]
    | [addr; instr] ->
        let addr = str_to_addr addr in
        let instr_list = Str.split (Str.regexp ";") instr in
        addr, instr_list
    | _ -> failwith "file format error"
  in
  let cfg =
    match words with
    | [addr; instr; cfg] ->
        let str_list = Str.split (Str.regexp " ") cfg in
        List.map str_to_addr str_list
    | [addr; instr] -> []
    | _ -> failwith "file format error"
  in
  addr, instr, cfg


(* to_addr_instr : string -> addr * instr list *)
let to_addr_instr line =
  let words = Str.split (Str.regexp "->") line in
  (* List.iter (fun w -> Printf.printf "%s\n" w) words; *)
  match words with
    | [addr; instr] ->
        let addr = str_to_addr addr in
        let instr_list = Str.split (Str.regexp ";") instr in
        addr, instr_list
    | _ -> failwith "file format error"

(* readlines : string -> string list 
 * readline filename
 * read lines in files, return a list of lines
 *)
let read_lines_from_file filename =
  let lines = ref [] in
  let chan = open_in filename in
  try
    while true; do
      let line = input_line chan in
      lines := line :: !lines
    done;
    []
  with End_of_file ->
    close_in chan;
    List.rev !lines

let read_lines_from_ic ic =
  let lines = ref [] in
  try
    while true; do
      let line = input_line ic in
      lines := line :: !lines
    done;
    []
  with End_of_file ->
    close_in ic;
    List.rev !lines

let file_to_pattern2 filename =
  let lines = read_lines_from_file filename in
  List.rev_map to_pattern2 (List.rev lines)

let file_to_pattern filename = 
  let lines = read_lines_from_file filename in
  List.rev_map to_pattern (List.rev lines)

let file_to_assem filename =
  let lines = read_lines_from_file filename in
  List.rev_map to_assem (List.rev lines)

(* string -> addr * addr list *)
(* string : name addr addr *)
let file_to_func_bound filename =
  let lines = read_lines_from_file filename in
  let name_bound_list = List.fold_left (fun l line -> 
    (to_func_bound line) :: l
  ) [] (List.rev lines)
  in
  let rec update res = function
    | (n1, s1, e1) :: (n2, s2, e2) :: tl ->
        let extend_n1 = Printf.sprintf "%s." n1 in
        if extend_n1 = n2 then
          let max = if Big_int_convenience.(>%) e1 e2 then e1 else e2 in
          update ((s1, max) :: (s2, max) :: res) tl
        else
          update ((s1, e1) :: res) ((n2, s2, e2) :: tl)
    | (n, s, e) :: tl -> update ((s, e) :: res) tl
    | [] -> List.rev res
  in
  let unsort = update [] name_bound_list in
  List.fast_sort (fun (s1, _) (s2, _) -> Big_int_Z.compare_big_int s1 s2) unsort 

let file_to_instr_stat filename =
  let lines = read_lines_from_file filename in
  List.fold_left (fun l line -> 
    (to_instr_stat line) :: l
  ) [] (List.rev lines)

let file_to_aic filename =
  let lines = read_lines_from_file filename in
  List.rev_map to_addr_instr_cfg (List.rev lines)

let file_to_ai filename =
  let lines = read_lines_from_file filename in
  List.fold_left (fun l line -> 
    (to_addr_instr line) :: l
  ) [] (List.rev lines)

let file_to_instr_p_n filename =
  let lines = read_lines_from_file filename in
  List.fold_left (fun l line -> 
    (to_instr_p_n line) :: l
  ) [] (List.rev lines)

let file_to_fb filename =
  let lines = read_lines_from_file filename in
  List.rev (List.rev_map to_fb lines)

let ic_to_model ic =
  let lines = read_lines_from_ic ic in
  List.map to_model lines
