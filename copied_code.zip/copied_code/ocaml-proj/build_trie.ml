(* This file is for match.ml in util*)
module D = Debug.Make(struct let name = "Build_trie" and default=`NoDebug end)
open D

type instr = string

module Instr = struct
  type t = instr
  let compare a b = String.compare a b
  (* is_pattern : a is the pattern of b *)
  let is_pattern a b = Str.string_match (Str.regexp a) b 0
  let format a = a 
end

module InstrMap = struct 
  include Map.Make(Instr)
  let is_pattern = Instr.is_pattern
  let format = Instr.format
end

module InstrTrie = Trie.Make(InstrMap)


(* build_trie : string -> InstrTrie.t
 * build_trie : build up the trie tree according to signature statistics file 
 * The format of each line in file is as followed:
 * push   %edi\n^[0-9a-f]+: push  %ebp->1 *)
let build_trie file =
  let pattern = Get_input.file_to_pattern file in
  let trie = InstrTrie.init 0.0 in
  List.fold_left ( fun t (k, v) ->
    InstrTrie.add k v t
  ) trie pattern

let rec get_instr res assem l =
  if l = 0 then List.rev res 
  else
  match assem with
  | (addr, instr) :: tl ->
      get_instr (instr::res) tl (l-1)
  | [] -> List.rev res

let rec forward_by_length l assem =
  if l = 0 then assem
  else match assem with
    | hd :: tl -> forward_by_length (l-1) tl
    | [] -> []

let rec forward_by_address addr = function
  | (a, i) :: tl -> if Big_int_Z.eq_big_int a addr then tl else
      forward_by_address addr tl
  | [] -> [] 

let rec rec_identify_function res trie assem p =
  match assem with
  | (addr, instr) :: tl ->
      dprintf "%lx %s\n" (Big_int_Z.int32_of_big_int addr) instr;
      let subinstr = get_instr [] assem 10 in
      (* List.iter (dprintf "%s\n") subinstr; *)
      (* score: the 'utility' got from trie 
       * length: the length of matched patter *)
      let score, length = InstrTrie.find_thb subinstr trie 
      in
      let score = match score with
        | Some s -> s
        | None -> 0.5
      in
      (* score > 0.5: the substring from addr to addr + length is a function start *)
      if score > 0.5 then (
        let res = addr::res in
        match p with
        | Some p -> (
          let endaddr =
            try (
              let cfg = Asmir_disasm.recursive_descent_at p addr in
              Some(Func_boundary.end_address_at cfg)
            )
            with _ -> None
            (* Func_boundary.end_address_at p addr
             * Func_boundary.RECURSIVE_DESCENT *)
          in
          match endaddr with
          | None ->
              (* The length is started at the head of the list, while we
              * start forwarding at the tl of the list, so the length sould be
              * substracted *)
              let next = forward_by_length (length-1) tl in
              rec_identify_function res trie next (Some p)
          | Some addr -> 
              let next = forward_by_address addr tl in
              rec_identify_function res trie next (Some p)
        )
        | None ->
          let next = forward_by_length (length-1) tl in
          rec_identify_function res trie next None
      )
      else rec_identify_function res trie tl p
  (* Although it is not necessary to order res, I do love to print it in
   * ascending order *)
  | [] -> List.rev res


let identify_function trie assem p =
  dprintf "identify function...\n";
  rec_identify_function [] trie assem p
