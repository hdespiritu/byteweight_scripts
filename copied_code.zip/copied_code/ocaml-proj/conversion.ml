module D = Debug.Make(struct let name = "Conversion" and default = `NoDebug end)

(* return the string of prologue. The returned string is deliminated by comma *)
let string_of_prologue p =
    let rec flat str = function
        | hd :: [] -> Printf.sprintf "%s%x" str hd
        | hd :: tl -> flat (Printf.sprintf "%s%x, " str hd) tl
        | [] -> str
    in flat "" p


