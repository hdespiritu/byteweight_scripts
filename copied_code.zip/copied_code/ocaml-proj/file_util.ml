
(* mkdir : string -> unit *)
let mkdir dir =
  try Unix.mkdir dir 0o755 with _ -> ()

(* check_and_open_out : string -> out_channel *)
let check_and_open_out file =
  let dir = Filename.dirname file in
  mkdir dir;
  open_out file

(* check_and_create : string -> string *)
let check_and_create dir =
  mkdir dir;
  dir
