let testf () =
  "Hooray!\n";;
