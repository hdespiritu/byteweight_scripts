(***********************************************************************)
(*                                                                     *)
(*                           Objective Caml                            *)
(*                                                                     *)
(*               Pierre Weis, projet Cristal, INRIA Rocquencourt       *)
(*                                                                     *)
(*  Copyright 2001 Institut National de Recherche en Informatique et   *)
(*  en Automatique.  All rights reserved.  This file is distributed    *)
(*  only by permission.                                                *)
(*                                                                     *)
(***********************************************************************)

(* Find the first occurrence of string [p] (the so-called ``pattern'')
   into the string [s].
   Elaborated algorithm.
   Knuth-Morris-Pratt algorithm following Sedgewick's book "Algorithms".
   The Caml code was proved correct in the Coq Proof Assistant.
   Based on a mail to the Caml list by Jean-Christophe FILLIATRE. *)

(* Modified by Tiffany Bao.  This is to count the positions that a pattern
 * occurs in binary program *)
(* Here p is byte sequence, the type is int list*)
module D = Debug.Make(struct let name = "KMP" and default = `NoDebug end)
open D

let init_next p =
  let m = List.length p in
  let next = Array.create m 0 in
  let i = ref 1 and j = ref 0 in
  while !i < m - 1 do
    if List.nth p (!i) = List.nth p (!j) then begin incr i; incr j; next.(!i) <- !j end else
    if !j = 0 then begin incr i; next.(!i) <- 0 end else j := next.(!j)
  done;
  next

let kmp p =
    dprintf "initial next table";
  let next = init_next p
  and m = List.length p in
  dprintf "match patterns";
  function s ->
    let n = List.length s
    and i = ref 0
    and j = ref 0 
    and res = ref [] in
    while !i < n do
      if snd(List.nth s !i) = List.nth p !j then (
          incr i; incr j;
          if !j = m then(
              let index = !i - !j in
              res := (fst (List.nth s index)) :: !res;
              j := next.(m - 1);
          )
      )
      else
      if !j = 0 then incr i else j := next.(!j)
    done;
    !res

let find_pat p s =
    let res = kmp p s in
    (match res with
    | [] -> print_string "Not found"
    | _ -> List.iter(fun i -> Printf.printf "%Lx\n" i) res);
    res
