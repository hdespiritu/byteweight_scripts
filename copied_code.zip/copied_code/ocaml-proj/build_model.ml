module D = Debug.Make(struct let name = "Build_model" and default=`NoDebug end)
open D

type instr = string

module type INSTR = sig
  type t
  val compare : t -> t -> int
  (* is_pattern : a is the pattern of b *)
  val is_pattern : t -> t -> bool
  val format : t -> string 
end

module Instr : (INSTR with type t = instr) = struct
  type t = instr
  let compare a b = String.compare a b
  (* is_pattern : a is the pattern of b *)
  let is_pattern a b =
    let p = Printf.sprintf "%s$" a in
    Str.string_match (Str.regexp p) b 0
  let format a = a 
end

module InstrMap = struct 
  include Map.Make(Instr)
  let is_pattern = Instr.is_pattern
  let format = Instr.format
end

module InstrTrie = Trie.Make(InstrMap)

let prune_prb trie =
  let after_prune =
    let should_prune (p, n) = 
      ((p = 0) || (n = 0)) && ((p != 0) || (n != 0))
    in
    InstrTrie.prune should_prune trie
  in
  InstrTrie.map (fun (p, n) -> 
    if p = 0 && n = 0 
    then 0.0 
    else float(p) /. (float(p) +. float(n))
  ) after_prune



(* build_trie : string -> InstrTrie.t
 * build_trie : build up the trie tree according to signature statistics file 
 * The format of each line in file is as followed:
 * push   %edi; push  %ebp->1 0*)
let build_trie file =
  let trie_init = InstrTrie.init 0.0 in
  Printf.printf "read trie\n%!";
  let pattern = Get_input.file_to_pattern file in
  Printf.printf "finish read trie\n%!";
  List.fold_left (fun t (k, v) ->
    InstrTrie.add k v t
  ) trie_init pattern
  (* in prune_prb trie *)

let addto_trie file trie =
  let pattern = Get_input.file_to_instr_p_n file in
  (* let pattern = Get_input.file_to_pattern file in *)
  List.fold_left ( fun t (k, v) ->
    InstrTrie.add k v t
  ) trie pattern



let rec get_instr addrs instrs assem l =
  if l = 0 then (List.rev addrs), (List.rev instrs)
  else
  match assem with
  | (addr, instr) :: tl ->
      get_instr (addr:: addrs) (instr::instrs) tl (l-1)
  | [] -> (List.rev addrs), (List.rev instrs)

let rec rec_build_model res trie assem p =
  match assem with
    (* start build model at 80493c2 *)
    (* | (s_addr, instr) :: tl when 
    (Big_int_Z.ge_big_int s_addr (Big_int_Z.big_int_of_int 0x80493c2)) -> *)
    | (s_addr, instr) :: tl ->
      dprintf "%lx %s\n" (Big_int_Z.int32_of_big_int s_addr) instr;
      (* If 10 instructions are matched, we need the 11th instruction to used as
       * end address. So we get 11 sub instructions from assem *)
      let subaddr, subinstr = get_instr [] [] assem 11 in
      List.iter (dprintf "%s\n") subinstr;
      List.iter (fun x -> dprintf "%lx" (Big_int_Z.int32_of_big_int x) ) subaddr;
      (* score: the 'utility' got from trie 
       * length: the length of matched patter *)
      let score, length = InstrTrie.find_thb subinstr trie in
      let score = match score with
        | Some score -> score
        | None -> 0.5
      in
      (* e_addr : end address, the address of the next address
       * e.g. 00000001   55  push %ebp is matched, but the following instruction
       * is not matched, then s_addr is 00000001, and e_addr is 00000002 
       * If no signature is matched, the start and end will be same 
       *)
      dprintf "%f %d" score length;
      dprintf "%d"  (List.length subaddr);
      if (length > 10) then Printf.printf "HORRIBLE!!!!!!!";
      let e_addr = 
        let len_subaddr = List.length subaddr in
        (* this means that subaddr is all matched and subaddr is a less-than-11 instruction list. *)
        if (len_subaddr <= length) then List.nth subaddr (len_subaddr - 1)
        else List.nth subaddr length
      in
      let func_addr_list = try (
        (* XXX: cfg recovery scheme should be configurable *)
        (* let cfg = Util.timeout ~secs:10 ~f:(Asmir_disasm.recursive_descent_at p)
        ~x: (Big_int_Z.big_int_of_int 0x80493c2) in *)
        let cfg = Util.timeout ~secs:10 ~f:(Asmir_disasm.recursive_descent_at p) ~x: s_addr in
        (* Cfg_pp.AstStmtsDot.output_graph stdout cfg; *)
        (* let cfg = Util.timeout ~secs:30 ~f:(Asmir_disasm.vsa_at p) ~x:s_addr in *)

        (* Get all the nodes' addresses from cfg *)
        Cfg.AST.G.fold_vertex (fun v addrs ->
          let stmts = Cfg.AST.get_stmts cfg v in
          List.fold_left (fun l -> function
            | Ast.Label(Type.Addr a, _) -> if List.mem a l then l else a::l
            | _ -> l
          ) addrs stmts
        ) cfg []
      )
      with e -> []

      in
      rec_build_model ((s_addr, e_addr, score, func_addr_list)::res) trie tl
      p
      (* [(s_addr, e_addr, score, func_addr_list)] *)
  (* | (s_addr, instr) :: tl -> rec_build_model res trie tl p *)
  (* Although it is not necessary to reverse res, I do love to print it in
   * ascending order *)
  | [] -> List.rev res

(* build_model : Trie.t -> (addr * string) list -> Asm.program ->
 *               (addr * addr * int * addr list ) list
 *)
let build_model trie assem p =
  rec_build_model [] trie assem p
