let usage = "Usage: "^Sys.argv.(0)^" -f <binary> -o <output model file> \
             -t <ground truth file> -o-
             translate binary to : instruction, times of occurence as function
               start, times of occurence as not a function start " 

open Big_int_convenience
type instr = string
type addr = Type.addr
type signal =
  | FUNC_START
  | NOT_FUNC_START
  | SHADOW

module Instr = struct
  type t = instr
  let compare a b = 
    let i_a = Str.split (Str.regexp ";") a in
    let i_b = Str.split (Str.regexp ";") b in
    let rec cmp i1 i2 = match i1, i2 with
      | _ :: _, [] -> 1
      | [], _ :: _ -> -1
      | h1 :: t1, h2 :: t2 ->
          if h1 = h2 then cmp t1 t2
          else compare h1 h2
      | [], [] -> 0
    in
    cmp i_a i_b

end
module InstrMap = Map.Make(Instr)

module AddrMap = BIM

let max_shadow_size = biconst 0x100
let oc = ref stdout
let oc_addr_instr = ref stdout
let oc_prf = ref stdout
let file = ref ""
let bfd_target = ref None
let nan = Big_int_convenience.bim1

let check_and_open ?(flag=Open_wronly) file =
  let dir = Filename.dirname file in
  (try Unix.mkdir dir 0o755 with _ -> ());
  open_out_gen [flag;Open_creat] 0o755 file

let speclist =
  (* input *)
  ("-f", Arg.String(fun f -> file := f), "input file")
  (* output *)
  :: ("-o-train", Arg.String(fun s -> oc := check_and_open s),
      "write train to file in format of instr1;instr2->p n")
  :: ("-o-test", Arg.String(fun s -> oc_addr_instr := check_and_open s), 
      "write test to file in format of addr->instr1;instr2...")
  :: ("-o-prf", Arg.String(fun s -> oc_prf := check_and_open ~flag:Open_append
  s),
      "write performance to file")
  (* setting *)
  :: ("-bfd-target", Arg.String(fun s -> bfd_target := Some s),
      "Set BFD target architecuture")
  :: []

let anon_fun _ = raise (Arg.Bad usage)

let parse_command = 
  Arg.parse speclist anon_fun usage;
  if !file = "" then
    raise (Arg.Bad usage)
  else
    !file

(* add : instr list -> signal -> (int * int) InstrMap *)
(* add sub[0..0], sub[0..1], ... sub [0..len - 1] to map *)
let add sub signal map =
  let rec work r_s map =
    match r_s with
    | [] -> map
    | _ :: others ->
        let instrs = List.rev r_s in
        let instrs_str = String.concat ";" instrs in
        let cnt_start, cnt_not_start = try InstrMap.find instrs_str map with _
        -> 0, 0 in
        let cnt_start, cnt_not_start = match signal with
        | FUNC_START -> cnt_start + 1, cnt_not_start
        | NOT_FUNC_START -> cnt_start, cnt_not_start + 1
        | SHADOW -> failwith "should't happend: SHADOW instruction should not
        occur in sub instructions"
        in
        let new_map = InstrMap.add instrs_str (cnt_start, cnt_not_start) map in
        work others new_map
  in
  let rev_sub = List.rev sub in
  work rev_sub map

(*model : signal AddrMap.t -> addr -> addr -> Asm.asmprogram
 * -> (int * int) InstrMap *)
let model shd start enD p =
  let is_shadow a =
    (* Printf.printf "%s\n%!" (Big_int_convenience.(~%) a); *)
    match AddrMap.find a shd with
    | SHADOW -> true
    | _ -> false
  in
  let rec process st en map =
    if st ==% en then map
    else if is_shadow st then process ((++%) st) en map
    else
      let sub = Func_boundary_util.get_dism p st 10 ~invalid:is_shadow en in
      let signal = AddrMap.find st shd in
      let new_map = add sub signal map in
      process ((++%) st) en new_map
  in
  process start enD InstrMap.empty


(* output gound truth to the corresponding file. 
 * Suppose file is in p_dir/dir/bin, we put ground truth in p_dir/gt/bin*)
let output_gt func_bound file =
  let dir = Filename.dirname file in
  let p_dir = Filename.dirname dir in
  let bin = Filename.basename file in
  let gt_dir = Filename.concat p_dir "gt" in
  (try Unix.mkdir gt_dir 0o755 with _ -> ());
  let gt_file = Filename.concat gt_dir bin in
  Printf.printf "%s\n" gt_file;
  let oc = open_out gt_file in
  let open Big_int_convenience in
  List.iter(fun (s,e) -> Printf.fprintf oc "%Lx %Lx\n" (addr_to_int64 s)
  (addr_to_int64 e)) func_bound;
  close_out oc

(* get the symbol table *)
(* TODO: use first-class module *)
let mark_addr_gt file p st nd =
  (* add addr as key to map from a to finish - 1 *)
  let rec add_addr a signal finish map =
    if Big_int_convenience.(==%) a finish then map
    else
      let map = AddrMap.add a signal map in
      add_addr (Big_int_convenience.(++%) a) signal finish map
  in

  let ground_truth =
    let tmp_file = Filename.temp_file "instr_stat" ".tmp" in
    let command =
      match !bfd_target with
      | None ->
        Printf.sprintf "objdump -t %s | grep \"F .text\" | gawk \
          '{start=strtonum(\"0x\"$1); size=strtonum(\"0x\"$5); printf(\"%%s%%s %%x %%x\\n\", \
          $6, $7, start, start+size)}' | sort -u > %s" file tmp_file
      | Some target when (target = "elf64-x86-64") || (target = "elf32-i386") ->
        Printf.sprintf "objdump -t %s --target=%s | grep \"F .text\" | gawk \
          '{start=strtonum(\"0x\"$1); size=strtonum(\"0x\"$5); printf(\"%%s%%s %%x %%x\\n\", \
          $6, $7, start, start+size)}' | sort -u > %s" file target tmp_file
      | Some target when (target = "mach-o-x86-64") || (target = "mach-o-i386") ->
        Printf.sprintf "objdump -t %s --target=%s --section=.text | \
          grep \"FUN\" | gawk '{start=strtonum(\"0x\"$1); printf(\"%%s%%s %%x %%x\\n\", \
          $7, $8, start, start)}'| grep -v \"^ 0 0$\" | sort -u > %s"
          file target tmp_file
      | _ -> failwith "target error"
    in
    let _ = Sys.command command in
    let func_bound = Get_input.file_to_func_bound tmp_file in
    List.map (fun (s, e) ->
      if Big_int_convenience.(==%) s e then s, nan
      (* else(
        let back = (Big_int_convenience.(-%) e Big_int_convenience.bi1) in
        let dism =
          try
          List.hd (Func_boundary_util.get_dism p back 1 e)
          with _ -> "nop"
        in
        if dism = "nop" then s, back else s, e 
      ) *)
      else s, e
    ) func_bound
  in
  let map = 
    let init_map = add_addr st NOT_FUNC_START nd AddrMap.empty in
    List.fold_left (fun map (s, _) ->
      AddrMap.add s FUNC_START map
    ) init_map ground_truth
  in
  map, ground_truth


let output_symbol map =
  AddrMap.iter (fun k v ->
    let open Big_int_convenience in
    match v with
    | SHADOW -> Printf.printf "%s SHADOW\n" (~% k) 
    | FUNC_START -> Printf.printf "%s FUNC_START\n" (~% k)
    | NOT_FUNC_START -> Printf.printf "%s NOT_FUNC_START\n" (~% k)
  ) map

let train_gt file =
  let p = Asmir.open_program ?target:!bfd_target file in
  let start = Asmir. get_section_startaddr p ".text" in
  let enD = Asmir.get_section_endaddr p ".text" in
  (* let instrs = get_addr_dism file in *)
  (* addr_shd : signal AddrMap.t
   * this map is designed for 0-size symbol in training test
   *)
  let addr_shd, func_bound = mark_addr_gt file p start enD in
  (* output_symbol addr_shd; *)
  (* ATTENTION: InstrMap is not the one in addr_instr. Here the key in InstrMap
   * is instruction (string), not the address of instruction (Big_int_Z.t) *)
  (model addr_shd start enD p), func_bound

let test file =
  (* to_test : addr -> addr -> Asm.asmprogram
  * -> (addr * string) list *)
  let to_test start enD p =
    let rec process st en addr_instr_l =
      if st ==% en then List.rev addr_instr_l
      else(
        let instrs = Func_boundary_util.get_dism p st 10 en in
        if instrs = [] then
          process ((++%) st) en addr_instr_l
        else
          let instrs_str = String.concat ";" instrs in
          process ((++%) st) en ((st, instrs_str)::addr_instr_l)
      )
    in
    process start enD []
  in
  let p = Asmir.open_program ?target:!bfd_target file in
  let start = Asmir. get_section_startaddr p ".text" in
  let enD = Asmir.get_section_endaddr p ".text" in
  to_test start enD p

let output_train map oc =
  InstrMap.iter(fun k (s, n_s) ->
    Printf.fprintf oc "%s->%d %d\n" k s n_s;
  ) map

(* output_test : (addr * string) list -> out_channal -> unit *)
let output_test l oc =
  List.iter(fun (addr, instr_str) ->
    Printf.fprintf oc "%Lx->%s\n" (addr_to_int64 addr) instr_str;
  ) l

let () =
  let file = parse_command in

  (* == Train and Ground Truth == *)
  let time_st = Sys.time () in
  let instr_stat, func_bound = train_gt file in
  (* output train statistics *)
  output_train instr_stat !oc;
  close_out !oc;
  let time_nd = Sys.time () in 
  (* output performance of training instruction extraction *)
  Printf.fprintf !oc_prf "train, extraction, %s, %f\n"
    (Filename.basename file) (time_nd -. time_st);
 
  (* output ground truth *)
  output_gt func_bound file;

  (* == Test == *)
  let time_st = Sys.time () in
  let addr_instr = test file in
  (* output test disassembly *)
  output_test addr_instr !oc_addr_instr;
  close_out !oc_addr_instr;
  let time_nd = Sys.time() in
  (* output performance of testing instruction extraction *)
  Printf.fprintf !oc_prf "test, extraction, %s, %f\n"
    (Filename.basename file) (time_nd -. time_st);
  
  close_out !oc_prf
