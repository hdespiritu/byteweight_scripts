let usage = "Usage: "^Sys.argv.(0)^" -f <binary> -o <output model file> \
             -t <ground truth file> -o-
             translate binary to : instruction, times of occurence as function
               start, times of occurence as not a function start " 

open Big_int_convenience
type instr = string
type addr = Type.addr
type signal =
  | FUNC_START
  | NOT_FUNC_START
  | SHADOW

module Instr = struct
  type t = instr
  let compare a b = 
    let i_a = Str.split (Str.regexp ";") a in
    let i_b = Str.split (Str.regexp ";") b in
    let rec cmp i1 i2 = match i1, i2 with
      | _ :: _, [] -> 1
      | [], _ :: _ -> -1
      | h1 :: t1, h2 :: t2 ->
          if h1 = h2 then cmp t1 t2
          else compare h1 h2
      | [], [] -> 0
    in
    cmp i_a i_b
  let equal a b =
    (compare a b = 0)
  let hash = Hashtbl.hash
end
module InstrMap = Hashtbl.Make(Instr)

module AddrMap = BIM

let file = ref ""
let gt = ref ""
let oc_prf = ref stdout
let test_dir = ref ""
let train_dir = ref ""
let gt_dir = ref ""
let bfd_target = ref None
let nan = Big_int_convenience.bim1
let fold = 10
(* 5000 is the guess of number of elements *)
let train_map = InstrMap.create 5000

let check_and_open ?(flag=Open_wronly) file =
  let dir = Filename.dirname file in
  (try Unix.mkdir dir 0o755 with _ -> ());
  open_out_gen [flag;Open_creat] 0o755 file

let speclist =
  (* input *)
  ("-f", Arg.Set_string file, "input file")
  :: ("-gt", Arg.Set_string gt, "grount truth file")
  (* output *)
  :: ("-o-train-dir", Arg.Set_string train_dir,
      "write train to directory in format of instr1;instr2->p n")
  :: ("-o-test-dir", Arg.Set_string test_dir, 
      "write test to directory in format of addr->instr1;instr2...")
  :: ("-o-gt-dir", Arg.Set_string gt_dir, 
      "write ground truth to directory in format of addr addr")
  :: ("-o-prf", Arg.String(fun s -> oc_prf := check_and_open ~flag:Open_append s),
      "write performance to file")
  (* setting *)
  :: ("-bfd-target", Arg.String(fun s -> bfd_target := Some s),
      "Set BFD target architecuture")
  :: []

let anon_fun _ = raise (Arg.Bad usage)

let parse_command = 
  Arg.parse speclist anon_fun usage;
  if !file = "" || !gt = "" then
    raise (Arg.Bad usage)
  else
    !file, !gt

(* add : instr list -> signal -> (int * int) InstrMap *)
(* add sub[0..0], sub[0..1], ... sub [0..len - 1] to map *)
let add sub signal =
  let rec work r_s =
    match r_s with
    | [] -> ()
    | _ :: others ->
        let instrs = List.rev r_s in
        let instrs_str = String.concat ";" instrs in
        let cnt_start, cnt_not_start = 
          try InstrMap.find train_map instrs_str
          with _ -> 0, 0
        in
        let cnt_start, cnt_not_start =
          match signal with
          | FUNC_START -> cnt_start + 1, cnt_not_start
          | NOT_FUNC_START -> cnt_start, cnt_not_start + 1
          | SHADOW -> failwith "should't happend: SHADOW instruction should not
          occur in sub instructions"
        in
        InstrMap.replace train_map instrs_str (cnt_start, cnt_not_start);
        work others
  in
  let rev_sub = List.rev sub in
  work rev_sub

(* output gound truth to the corresponding file. 
 * Suppose file is in p_dir/dir/bin, we put ground truth in p_dir/gt/bin*)
let output_gt func_bound oc =
  let open Big_int_convenience in
  List.iter(fun (s,e) -> Printf.fprintf oc "%Lx %Lx\n" (addr_to_int64 s)
  (addr_to_int64 e)) func_bound;
  close_out oc

let output_train map oc =
  InstrMap.iter(fun k (s, n_s) ->
    Printf.fprintf oc "%s->%d %d\n" k s n_s;
  ) map;
  close_out oc

(* output_test : (addr * string) list -> out_channal -> unit *)
let output_test l oc =
  List.iter(fun (addr, instr_str) ->
    Printf.fprintf oc "%Lx->%s\n" (addr_to_int64 addr) instr_str;
  ) l;
  close_out oc

let model p start enD gt =
  let open Big_int_convenience in 
  let rec process st en test_list =
    (* if (Int64.to_int (addr_to_int64 st)) mod 0x1000 = 0 then
      Printf.printf "%Lx\n%!" (addr_to_int64 st); *)
    if st ==% en then train_map, (List.rev test_list)
    else
      let instrs = Func_boundary_util.get_dism p st 10 en in
      if instrs = [] then
          process ((++%) st) en test_list
      else (
        let test_list_update =
          let instrs_str = String.concat ";" instrs in
          (st, instrs_str) :: test_list
        in
        let signal =
            if List.mem st gt then FUNC_START
            else NOT_FUNC_START
        in
        add instrs signal;
        process ((++%) st) en test_list_update
      )
  in
  process start enD []


let () =
  let file, gt = parse_command in
  Printf.printf "Open program...\n%!";
  let p = Asmir.open_program ?target:!bfd_target file in

  Printf.printf "Read ground truth...\n%!";
  let gt_list = Get_input.file_to_fb gt
  and basename = 
    let with_ext = Filename.basename file in
    try Filename.chop_extension with_ext
    with _ -> with_ext
  in
  
  Printf.printf "Generate train and test...\n%!";
  let st = Asmir. get_section_startaddr p ".text"
  and nd = Asmir.get_section_endaddr p ".text" in
  let gt_st = List.map fst gt_list in
  let time_bgn = Sys.time () in
  (* Printf.printf "Start: %Lx, End: %Lx\n%!" (addr_to_int64 st) (addr_to_int64
  nd); *)
  let train, test = model p st nd gt_st in
  let time_end = Sys.time () in
  Printf.fprintf !oc_prf
    "train, extraction, %s, %f\n" basename (time_end -.time_bgn);
  
  let oc_test =
    let f = Filename.concat !test_dir basename in
    check_and_open f
  in
  output_test test oc_test;
  let oc_train =
    let f = Filename.concat !train_dir basename in
    check_and_open f
  in
  output_train train oc_train;
  close_out(oc_train);
  close_out(oc_test);
  
  close_out !oc_prf
