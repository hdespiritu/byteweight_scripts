exception Argument_error
exception Lack_file of string

type in_out = 
  | In of in_channel
  | Out of out_channel

let usage = "Usage: "^Sys.argv.(0)^" -a <assembly dir> -s <signature file> \
              -b <binary dir> \n \
             model testing assembly"

let c_mod = ref (Out stdout)
let oc_res = ref stdout
let sigfile = ref ""
let assemdir = ref ""
let bindir = ref ""

let speclist =
  ("-o", Arg.String(fun s -> c_mod := Out (open_out s)), "write model to file")
  :: ("-i", Arg.String(fun s -> c_mod := In (open_in s)), "read model from file")
  :: ("-res", Arg.String(fun s -> oc_res := open_out s), "output file")
  :: ("-a", Arg.String(fun s -> assemdir := s), "assembly dir")
  :: ("-s", Arg.String(fun s -> sigfile := s), "signature file")
  :: ("-b", Arg.String(fun s -> bindir := s), "binary dir")
  :: []

let anon_fun _ = raise (Arg.Bad usage)

let parse_command = 
  Arg.parse speclist anon_fun usage;
  Printf.printf "%s %s %s\n" !bindir !assemdir !sigfile; 
  if !bindir = "" || !assemdir = "" || !sigfile = "" then
    raise (Arg.Bad usage)
  else
    !assemdir, !bindir, !sigfile

let check_merge assemdir bindir =
  let binfiles = Sys.readdir bindir in
  let binfiles = Array.to_list binfiles in
  let binfiles = List.fast_sort compare binfiles in

  let assemfiles = Sys.readdir assemdir in
  let assemfiles = Array.to_list assemfiles in
  let assemfiles = List.fast_sort compare assemfiles in

  (* check if files in bin dir exist in assem dir *)
  List.iter (fun f ->
    let f = Printf.sprintf "%s.dism" f in 
    if not (List.mem f assemfiles) then
      let errmsg = Printf.sprintf "%s is not in %s" f assemdir in
      raise (Lack_file errmsg)
  ) binfiles;
  (* check if files in assem dir exist in bin dir *)
  List.iter (fun f ->
    let f = Str.global_replace (Str.regexp "\\.dism") "" f in 
    if not (List.mem f binfiles) then 
      raise (Lack_file (Printf.sprintf "%s is not in %s" f assemdir))
  ) assemfiles;
 
  let names = binfiles in
  List.map (fun n ->
    let assemfile = Printf.sprintf "%s/%s.dism" assemdir n in
    let binfile = Printf.sprintf "%s/%s" bindir n in
    assemfile, binfile, n
  ) names

let model_and_pick sigfile merged_list oc_mod =
  
  Printf.printf "build trie...\n%!";
  let trie = Build_model.build_trie sigfile in
  
  (* 
  let merged_list = List.filter (fun (_, _, name) -> not (Str.string_match (Str.regexp "sha") name 0)) merged_list
  in
  *)

  List.iter (fun (assem, bin, name) -> 
    Printf.printf "read assembly... %s\n%!" assem;
    let assem = Get_input.file_to_assem assem in
    
    Printf.printf "load binary... %s\n%!" bin;
    let p = Asmir.open_program bin in

    Printf.printf "model address...\n%!";
    (* model_list : (addr * addr * int * addr list) list *)
    (* model_list : 
     * matched signature start addr * matched signature end addr *
     * score * address list of instructions in a function ) list 
     *)
    let model_list = Build_model.build_model trie assem p in
    
    Printf.printf "output model...\n%!";
    Func_boundary_util.print_model oc_mod model_list name;

    Printf.printf "greedy pick...\n%!";
    let greedy_list = Greedy.greedy model_list in

    Printf.printf "output greedy result...\n%!";
    Func_boundary_util.print_res !oc_res greedy_list name

  ) merged_list


let just_pick merged_list ic_mod =
  Printf.printf "read in model...\n%!";
  let model_list = Get_input.ic_to_model ic_mod in

  List.iter (fun (_, _, name) ->
    Printf.printf "%s\n" name; 
    let bin_model_list = List.filter (fun (binname, _, _, _, _) -> compare name binname = 0) model_list in
    let bin_model_list = List.map (fun (_, st_addr, end_addr, scr, instrs) -> (st_addr, end_addr, scr, instrs)) bin_model_list in

    Printf.printf "greedy pick...\n%!";
    let greedy_list = Greedy.greedy bin_model_list in

    Printf.printf "output greedy result...\n%!";
    Func_boundary_util.print_res !oc_res greedy_list name

  ) merged_list

let main assemdir bindir sigfile =

  let merged_list = check_merge assemdir bindir
  in

  match !c_mod with
    | In ic_mod -> 
        just_pick merged_list ic_mod;
        close_in ic_mod
    | Out oc_mod ->
        model_and_pick sigfile merged_list oc_mod;
        close_out oc_mod


let () = 
  let assemdir, bindir, sigfile = parse_command in
  main assemdir bindir sigfile;
  close_out !oc_res
