(* Naive algorithm to find function boundary *)
let usage = "Usage: "^Sys.argv.(0)^
            "-i-d <binary directory> -i-f <binary> \n \
             -o-d <output directory> -o-f <output> \n \
             -bfd-target <bfd target> \n \
             A naive algorithm to identify function boundary."

let file_out = ref None
let dir_out = ref None
let file_in = ref None
let dir_in = ref None
let bfd_target = ref None

let speclist =
  ("-o-f", Arg.String(fun f -> file_out := Some (File_util.check_and_open_out f)), "output function boundary to file")
  :: ("-o-d", Arg.String(fun d -> dir_out := Some (File_util.check_and_create d)), "output function boundary to directory")
  :: ("-i-f", Arg.String(fun f -> file_in := Some f), "input binary file")
  :: ("-i-d", Arg.String(fun d -> dir_in := Some d), "input directory file")
  :: ("-bfd-target", Arg.String(fun s -> bfd_target := Some s), "Set BFD target
  architecuture")
  :: []


let fb_naive f oc =
  Printf.printf "%s\n" f;
  let p = Asmir.open_program ?target:!bfd_target f in
  let code = 
    let addr_char = Asmir.get_exec_mem_contents_list p in
    List.rev (List.rev_map (fun (a, c) -> (a, Char.code c)) addr_char)
  in
  let start_end = List.filter(fun (_, b) ->
    (b = 0xc3) || (b = 0x55)
  ) code
  in
  let rec pair res (l_a, last) = function
    | [] -> res
    | (_, b) :: others when b = last ->
        pair res (l_a, last) others
    | (a, 0xc3) :: others when last = 0x55 ->
        pair ((l_a, a) :: res) (a, 0xc3) others
    | (a, 0x55) :: others when last = 0xc3 ->
        pair res (a, 0x55) others
    | (a, _) :: _ -> let error_msg = Printf.sprintf "pair error at address %Lx"
    (Big_int_convenience.addr_to_int64 a) in
      failwith error_msg
  in
  let fb = pair [] (List.hd start_end) start_end in
  List.iter (fun (s, e) ->
    Printf.fprintf oc "%Lx %Lx\n" (Big_int_convenience.addr_to_int64 s)
    (Big_int_convenience.addr_to_int64 e)
  ) fb;
  close_out oc


let main dir_i dir_o =
  let files =
    let a = Sys.readdir dir_i in
    Array.to_list a
  in

  List.iter (fun f ->
    let infile = Printf.sprintf "%s/%s" dir_i f in
    let outfile = Printf.sprintf "%s/%s" dir_o f in
    let oc = open_out outfile in 
    
    fb_naive infile oc;

  ) files

let anon_fun _ = raise (Arg.Bad usage)

let parse_command =
  Arg.parse speclist anon_fun usage;
  match !file_in, !file_out, !dir_in, !dir_out with
  | Some f_i, Some f_o, None, None ->
      fb_naive f_i f_o
  | None, None, Some d_i, Some d_o ->
      main d_i d_o
  | _ -> raise (Arg.Bad usage)

let () = parse_command




