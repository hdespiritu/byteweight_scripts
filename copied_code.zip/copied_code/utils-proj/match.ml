
exception Argument_error
exception Lack_file of string

let usage = "Usage: "^Sys.argv.(0)^" [options] <assembly_file> <signature_file>\n\
             match signatures in signature_file with assembly"

let oc = ref stdout
let sigfile = ref ""
let assemdir = ref ""
let bindir = ref ""
let end_addr = ref false

let speclist =
  ("-o", Arg.String(fun s -> oc := open_out s), "output file")
  :: ("-a", Arg.String(fun s -> assemdir := s), "assembly dir")
  :: ("-s", Arg.String(fun s -> sigfile := s), "signature file")
  :: ("-b", Arg.String(fun s -> bindir := s), "binary dir")
  :: ("-end-addr", Arg.Unit(fun () -> end_addr := true), "find end address along
  with identifying function start address")
  :: []

let anon_fun _ = raise (Arg.Bad usage)


let parse_command = 
  Arg.parse speclist anon_fun usage;
  Printf.printf "%s %s %s" !bindir !assemdir !sigfile; 
  if (!bindir = "" && !end_addr) || !assemdir = "" || !sigfile = "" then
    raise (Arg.Bad usage)
  else
    !assemdir, !bindir, !sigfile, !end_addr


let print start_list binname =
  List.iter (fun addr ->
    Printf.fprintf !oc "%s %lx\n" binname (Big_int_Z.int32_of_big_int addr)
  ) start_list


let check_merge assemdir bindir =
  let binfiles = Sys.readdir bindir in
  let binfiles = Array.to_list binfiles in
  let binfiles = List.fast_sort compare binfiles in

  let assemfiles = Sys.readdir assemdir in
  let assemfiles = Array.to_list assemfiles in
  let assemfiles = List.fast_sort compare assemfiles in

  (* check if files in bin dir exist in assem dir *)
  List.iter (fun f ->
    let f = Printf.sprintf "%s.dism" f in 
    if not (List.mem f assemfiles) then
      let errmsg = Printf.sprintf "%s is not in %s" f assemdir in
      raise (Lack_file errmsg)
  ) binfiles;
  (* check if files in assem dir exist in bin dir *)
  List.iter (fun f ->
    let f = Str.global_replace (Str.regexp "\\.dism") "" f in 
    if not (List.mem f binfiles) then 
      raise (Lack_file (Printf.sprintf "%s is not in %s" f assemdir))
  ) assemfiles;
 
  let names = binfiles in
  List.map (fun n ->
    let assemfile = Printf.sprintf "%s/%s.dism" assemdir n in
    let binfile = Printf.sprintf "%s/%s" bindir n in
    assemfile, binfile, n
  ) names

let main assemdir bindir sigfile end_addr =
  Printf.printf "build trie...\n%!";
  let trie = Build_trie.build_trie sigfile in

  if end_addr then (
    let merged_list = check_merge assemdir bindir
    in

    List.iter (fun (assem, bin, name) -> 
      Printf.printf "read assembly... %s\n%!" assem;
      let assem = Get_input.file_to_assem assem in
      
      Printf.printf "load binary ... %s\n%!" bin;
      let p = Asmir.open_program bin in

      Printf.printf "identify function...\n%!";
      let start_list = Build_trie.identify_function trie assem (Some p) in
      
      Printf.printf "output result...\n%!";
      Func_boundary_util.print_res !oc start_list name
    ) merged_list
  )
  else (
    let assemfiles = Sys.readdir assemdir in
    let assemfiles = Array.to_list assemfiles in
    let assemfiles = List.fast_sort compare assemfiles in

    let merged_list = List.map (fun assem -> 
      let name = Filename.chop_extension assem in
      let assem = Printf.sprintf "%s/%s" assemdir assem in
      assem, name
    ) assemfiles
    in

    List.iter (fun (assem, name) -> 
      Printf.printf "read assembly... %s\n%!" assem;
      let assem = Get_input.file_to_assem assem in
      
      Printf.printf "identify function...\n%!";
      let start_list = Build_trie.identify_function trie assem None in
      
      Printf.printf "output result...\n%!";
      print start_list name
    ) merged_list
  )


let () = 
  let assemdir, bindir, sigfile, end_addr = parse_command in
  main assemdir bindir sigfile end_addr;
  close_out !oc
