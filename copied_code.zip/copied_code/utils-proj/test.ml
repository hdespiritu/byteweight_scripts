(* input : 1. modeled signature-statistics file 
 *         2. modeled testing directory, in which files are modeled as addr dism
 *         cfg 
 * output : 3. modeled testing directory, in which files are modeled as 
 *             <addr> <length of matching> <score> <cfg>
 *          4. the selecting result *)
exception Argument_error
exception Instr_duplication
exception Lack_file of string

let usage = "Usage: "^Sys.argv.(0)^" -i-dir <modeled testing dir> -sig-dir \
             <signature directory> -sig-file <signature file> \
              -o-dir <output scored testing model dir> -res <output selecting file>"

let d_mdl = ref ""
let d_scr = ref ""
let d_fb = ref ""
let d_sig = ref ""
let f_sig = ref ""
let d_bin = ref ""
let oc_prf = ref stdout
let bfd_target = ref None
let nan = Big_int_convenience.bim1

type sig_input =
  | FILE of string
  | DIR of string

let speclist =
  ("-i-dir", Arg.String(fun s -> d_mdl := s), "modeled test dir")
  :: ("-bin-dir", Arg.String(fun s -> d_bin := s), "function start address dir")
  :: ("-sig-dir", Arg.String(fun s -> d_sig := s), "signature dir")
  :: ("-sig-file", Arg.String(fun s -> f_sig := s), "pruned signature file")
  :: ("-bfd-target", Arg.String(fun s -> bfd_target := Some s), "Set BFD target
  architecuture")
  (* below are two outputs, and a performance file *)
  :: ("-o-dir", Arg.String(fun s -> (try Unix.mkdir s 0o755 with _ -> ());
    d_scr := s), "scored modeled test dir")
  :: ("-fb-dir", Arg.String(fun s -> (try Unix.mkdir s 0o755 with _ -> ());
    d_fb := s), "function boundary dir")
  :: ("-o-prf", Arg.String(fun s -> 
    oc_prf := open_out_gen [Open_wronly;Open_append;Open_creat] 0o755 s; 
      Printf.fprintf !oc_prf "phase, subphase, binary, time\n"
  ), "performance file")
  :: []

let anon_fun _ = raise (Arg.Bad usage)

let parse_command = 
  Arg.parse speclist anon_fun usage;
  Printf.printf "%s %s\n" !d_mdl !d_sig; 
  if !d_mdl = "" 
     || (!d_sig = "" && !f_sig = "") 
     || !d_scr = "" 
     || (!d_sig <> ""&& !f_sig <> "") 
  then
    raise (Arg.Bad usage)
  else if !d_sig <> "" then
    !d_mdl, DIR !d_sig, !d_scr, !d_fb, !d_bin
  else
    !d_mdl, FILE !f_sig, !d_scr, !d_fb, !d_bin



(* output : (addr * float * int) list -> string -> unit *)
let output asl out =
  let oc = open_out out in
  List.iter (fun (addr, scr, len) ->
    let addr = Big_int_convenience.addr_to_int64 addr in
    (* let cfg_str_list = List.map Big_int_convenience.(~%) cfg in
    let cfg_str = String.concat " " cfg_str_list in *)
    Printf.fprintf oc "%Lx->%f->%d\n" addr scr len
  ) asl;
  close_out oc

let output_fb fb_list out =
  let oc = open_out out in
  List.iter (fun (st, nd) ->
    Printf.fprintf oc "%Lx %Lx\n" (Big_int_convenience.addr_to_int64 st)
    (Big_int_convenience.addr_to_int64 nd)
  ) fb_list;
  close_out oc

let output_fi fi_list out =
  let oc = open_out out in
  List.iter (fun l ->
    let line = 
      let list_s =
        List.map (fun (st, nd) ->
          Printf.sprintf "%Lx %Lx" 
            (Big_int_convenience.addr_to_int64 st)
            (Big_int_convenience.addr_to_int64 nd)
        ) l
      in
      String.concat " " list_s
    in
    Printf.fprintf oc "%s\n" line
  ) fi_list;
  close_out oc


let process in_out_start_list trie =
  List.iter(fun (iN, out, fb, bin) ->
    Printf.printf "%s --> %s\n%!" iN out;
    Printf.printf "Reading input...\n%!";
    (*aic_list : (addr * instr(string) list * addr list) list *)
    (* let aic_list = Get_input.file_to_aic iN in *)
    (*ai_list : (addr * instr(string) list) list *)
    let ai_list = Get_input.file_to_ai iN in
    Printf.printf "Matching...\n%!";
    let time_bgn = Sys.time () in
    let asl = List.rev_map (fun (addr, instr) ->
      let scr, len = Build_model.InstrTrie.find_thb (List.map Get_input.simplify instr) trie in
      (* Printf.printf "%Lx : %f\n%!" (Big_int_convenience.addr_to_int64 addr)
      (time_end -. time_bgn); *)
      
      let scr = match scr with
        | Some s -> s
        | None -> 0.5 (* 0.5 or 0.0? *)
      in
      (addr, scr, len)
    ) (List.rev ai_list)
    in
    let time_end = Sys.time () in
    Printf.fprintf !oc_prf "test, matching, %s, %f\n%!" (Filename.basename bin) (time_end -. time_bgn);
    Printf.printf "Finish matching : %f\n%!" (time_end -. time_bgn);
    
    Printf.printf "Outputting score to %s ...\n%!" out;
    output asl out;
   
    
    Printf.printf "Start Identifying...\n%!";
    let start_list = List.filter (fun (_, s, _) -> s > 0.5) asl in
    
    (* Function Identification *)
    (*
     * Printf.printf "Function Identifying...\n%!";
     * let merge instrs_range =
     *   let rec merge_rec l min max = function 
     *     | (st, nd) :: tl ->
     *       if st <= max then merge_rec l min nd tl
     *       else merge_rec ((min, max) :: l) st nd tl
     *     | [] -> (min, max) :: l
     *   in
     *   let st, nd = List.hd instrs_range in
     *   merge_rec [] st nd instrs_range
     * in      
     * let p = Asmir.open_program ?target:!bfd_target bin in
     * let func_range_list = List.map (fun (func_st, _, _) ->
     *   let sorted_func_instrs_start = Func_boundary_util.get_func_instr p func_st Func_boundary_util.VSA in
     *   match sorted_func_instrs_start with
     *   | Some s when List.length s > 0 ->
     *     let sorted_func_instrs_range =
     *       List.map (fun i_s ->
     *         let _, i_e = Asmir.asm_addr_to_bap p i_s
     *         in i_s, i_e
     *       ) s 
     *     in
     *     merge sorted_func_instrs_range
     *   | _ -> [func_st, nan]
     * ) start_list
     * in
     * output_fi func_range_list fb
     *)

    (*
     * Below is function boundary identification. Since function identification
     * already includes function boundary identification, we comment the code
     * now. If one wants only function boundary identification, he can switch
     * the code
     *)
    Printf.printf "Boundary Identifying...\n%!";
    let time_bgn = Sys.time () in
    let start_end_list = 
      let p = Asmir.open_program ?target:!bfd_target bin in
      List.map (fun (func_st, _, _) ->
        let instrs = Func_boundary_util.get_func_instr p func_st Func_boundary_util.VSA in
        let func_end = match instrs with
          | Some l -> 
              (* Printf.printf "cfg succuss in %Lx!\n" 
                (Big_int_convenience.addr_to_int64 func_st); *)
              if List.length l > 0 then
                let st_last_instr = List.nth l (List.length l - 1) in
                (* func_end is the end of instruction; but we want the end of end, so we
                * get the next instruction func_end *)
                let _, end_last_instr = Asmir.asm_addr_to_bap p st_last_instr in
                end_last_instr
              else nan
          | None -> nan
        in
        func_st, func_end
      ) start_list
    in
    let time_end = Sys.time () in
    Printf.fprintf !oc_prf "test, boundary, %s, %f\n%!" (Filename.basename bin) (time_end -.
    time_bgn);
    output_fb start_end_list fb

  ) in_out_start_list

(* l1 is the sub-instructions of l2 *)
let rec sub l1 l2 = match l1, l2 with
  | h1 :: t1, h2 :: t2 ->
      if h1 = h2 then sub t1 t2
      else false
  | _ :: _, [] -> false
  | [], [] -> (* raise Instr_duplication  *) true
  | [], _ :: _ -> true

let eq l1 l2 =
  try l1 = l2
  with _ -> false

let rec forward cond cntn ic = function
  | None -> None
  | Some (instrs, cnt)->
    (* Printf.printf "\t\tInstruction: %s\n" (String.concat ";" instrs); *)
    if cntn cond instrs then
      let up_crs = Get_input.to_instr_p_n (input_line ic) in
      forward cond cntn ic (Some up_crs)
    else
      Some (instrs, cnt)

let all_finish curs =
  List.fold_left (fun t s -> match s with
    | Some _ -> false
    | None -> t && true
  ) true curs

let rec insert_node cursors ics trie =
  let mininstrs, (minp, minn) = 
    let rec (>*) l1 l2 = match l1, l2 with
      | h1 :: _, h2 :: _ when String.compare h1 h2 > 0 -> true
      | h1 :: _, h2 :: _ when String.compare h1 h2 < 0 -> false
      | _ :: t1, _ :: t2 -> t1 >* t2
      | [], [] -> false
      | _, [] -> true
      | [], _ -> false
    in
    let (=*) l1 l2 =
      let ll1 = String.concat ";" l1 and
      ll2 = String.concat ";" l2 in
      if String.compare ll1 ll2 = 0 then true
      else false
    in
    let init =
      let rec f = function
        | Some hd :: tl ->
            (fst hd, (0, 0))
        | None :: tl -> f tl
        | _ -> failwith "Impossible"
      in
      f cursors
    in

    List.fold_left (fun (m, (p, n)) c -> match c with
      | Some (instrs, (tp, tn)) ->
        if m >* instrs then instrs, (tp, tn)
        else if m =* instrs then m, (p + tp, n + tn)
        else m, (p, n)
      | _ -> m, (p, n)
    ) init cursors
  in
  (* Printf.printf "%s -> %d %d\n%!" (String.concat ";" mininstrs) minp minn; *)
  let prb = 
    if minp = 0 && minn = 0 then 0.0
    else float(minp) /. float(minp + minn)
  in
  let update_trie =
    let simp_instr = List.map Get_input.simplify mininstrs in
    Build_model.InstrTrie.add simp_instr prb trie
  in
  let update_cursors =
    let continue =
      if minp = 0 || minn = 0 then sub else eq
    in
    (* Printf.printf "Foward after %s\n%!" (String.concat ";" mininstrs); *)
    (* List.rev_map2 (forward mininstrs continue) (List.rev ics) (List.rev
     * cursors) *)
    List.rev (
      List.rev_map2 (fun ic curs -> 
        (* Printf.printf "\tFile Begin\n"; *)
        try
          forward mininstrs continue ic curs
        with 
         | End_of_file -> None
         | Instr_duplication -> 
            let msg = Printf.sprintf "Same instruction happens twice %s"
              (String.concat ";" mininstrs ) in
            failwith msg
      ) ics cursors
    )
  in
  if all_finish update_cursors then update_trie
  else
    insert_node update_cursors ics update_trie

let build_trie dir =
  let ics = 
    let files = 
      let bins = Array.to_list (Sys.readdir dir) in
      List.map (Filename.concat dir) bins
    in
    List.map open_in files 
  in
  Printf.printf "initilize cursors...\n%!";
  let cursors_init = List.rev_map (fun ic -> 
    try Some (Get_input.to_instr_p_n (input_line ic))
    with _ -> None
  ) (List.rev ics) in
  let trie_init = Build_model.InstrTrie.init 0.0 in
  
  Printf.printf "insert node...\n%!";
  insert_node cursors_init ics trie_init


let main modeldir sigin scoredir fbdir bindir =
  Printf.printf "Building trie....\n%!";
  Printf.printf "fb dir: %s\n%!" fbdir;

  let sigtrie = 
    match sigin with
      | DIR sigdir ->
          (* build up the trie tree by sigdir *)
          (* let sigtrie = 
            let trie_init = Build_model.InstrTrie.init (0, 0) in
            let files = Array.to_list (Sys.readdir sigdir) in
            let insert_trie trie file =
              let infile = Filename.concat sigdir file in
              Printf.printf "\tadd %s to trie...\n%!" infile;
              let update_trie = Build_model.addto_trie infile trie in
              update_trie
            in
            let trie_bfr_prune = List.fold_left insert_trie trie_init files in
            Build_model.prune_prb trie_bfr_prune
          in *)
          let time_bgn = Sys.time () in
          let trie = build_trie sigdir in
          let time_end = Sys.time () in
          Printf.fprintf !oc_prf "train, building, all, %f\n%!" (time_end -.
          time_bgn);
          trie
      | FILE sigfile -> 
          let time_bgn = Sys.time () in
          let trie = Build_model.build_trie sigfile in
          let time_end = Sys.time () in
          Printf.fprintf !oc_prf "train, reading, all, %f\n%!" (time_end -.
          time_bgn);
          trie
  in
  Printf.printf "Finish Building Trie...\n";
  
  (* Output pruned trie *)
  let oc = 
    (* let tmp_file = Filename.temp_file "pruned_trie" ".tmp" in
    Printf.printf "pruned trie file : %s\n" tmp_file;
    open_out tmp_file *)
    let filename = 
      Filename.concat (Filename.dirname scoredir) "pruned_trie" 
    in
    open_out filename
  in
  Build_model.InstrTrie.print string_of_float sigtrie oc;
  close_out oc;
  
  Printf.printf "Generating list....\n%!";
  (* open each test model file, score each line according to trie, and write
   * back *)
  let in_out_start_list =
    let mdlfiles = 
      let a = Sys.readdir modeldir in
      List.fast_sort compare (Array.to_list a)
    in
    List.map (fun bin ->
      let iN = Filename.concat modeldir bin in
      let out = Filename.concat scoredir bin in
      let fb = Filename.concat fbdir bin in
      let bin = Filename.concat bindir bin in
      iN, out, fb, bin
    ) mdlfiles
  in
  let update_in_out_start_list =
    List.filter (fun (_, scr, fb, _) ->
      not (Sys.file_exists scr && Sys.file_exists fb)
    ) in_out_start_list
  in
  Printf.printf "Process test files....\n%!";
  process update_in_out_start_list sigtrie;
  close_out !oc_prf


let () = 
  let d_model, sig_in, d_score, d_fb, d_bin = parse_command in
  main d_model sig_in d_score d_fb d_bin

