(* input : 1. modeled signature-statistics file 
 *         2. modeled testing directory, in which files are modeled as addr dism
 *         cfg 
 * output : 3. modeled testing directory, in which files are modeled as 
 *             <addr> <length of matching> <score> <cfg>
 *          4. the selecting result *)
exception Argument_error
exception Instr_duplication
exception Lack_file of string

let usage = "Usage: "^Sys.argv.(0)^" -i-dir <modeled testing dir> -sig-dir \
             <signature directory> -sig-file <signature file> \
              -o-dir <output scored testing model dir> -res <output selecting file>"

let d_fb = ref ""
let d_fb_call = ref ""
let d_bin = ref ""
let oc_prf = ref stdout
let bfd_target = ref None
let nan = Big_int_convenience.bim1

let speclist =
  (* Input : binary dir, known function boundary dir, and bfd target *)
  ("-bin-dir", Arg.String(fun s -> d_bin := s), "function start address dir")
  :: ("-fb-dir", Arg.String(fun s -> d_fb := s), "function start address dir")
  :: ("-bfd-target", Arg.String(fun s -> bfd_target := Some s), "Set BFD target
  architecuture")
  (* Output : 
   * 1. upgraded function boundary dir, in which callee is added into
   * function start. 
   * 2. performance file
   *)
  :: ("-fb-call-dir", Arg.String(fun s -> (try Unix.mkdir s 0o755 with _ -> ());
    d_fb_call := s), "scored modeled test dir")
  :: ("-o-prf", Arg.String(fun s ->
    let exists = Sys.file_exists s in
    oc_prf := open_out_gen [Open_wronly;Open_append;Open_creat] 0o755 s;
    if not exists then
      Printf.fprintf !oc_prf "phase, subphase, binary, time\n"
    ), "performance file")
  :: []

let anon_fun _ = raise (Arg.Bad usage)

let parse_command = 
  Arg.parse speclist anon_fun usage;
  if (!d_bin = "") || (!d_fb = "") || (!d_fb_call = "")
  then
    raise (Arg.Bad usage)
  else
    !d_fb, !d_bin, !d_fb_call

let output_fb fb_list out =
  let oc = open_out out in
  List.iter (fun (st, nd) ->
    Printf.fprintf oc "%Lx %Lx\n" (Big_int_convenience.addr_to_int64 st)
    (Big_int_convenience.addr_to_int64 nd)
  ) fb_list;
  close_out oc

let extend fb_list p start enD =
  (* old_fb : function boundary that does not contain new_fs 
   * merged_fs : function start that contains new_fs
   * new_fs : function start that are newly added thus not identified function
   * boundary yet
   *)
  let rec rec_extend old_fb merged_fs new_fs =
    Printf.printf "Current function starts :";
    List.iter (fun a ->
      Printf.printf "%Lx " (Big_int_convenience.addr_to_int64 a)
    ) merged_fs;
    Printf.printf "\n%!";
    let new_new_fs, new_fb =
      List.fold_left (fun (t_new_new_fs, t_new_fb) st ->
        let addrs, callees = Func_boundary_util.get_func_addrs_callees
          p st Func_boundary_util.VSA
        in
        let nd = 
          (* Printf.printf "cfg succuss in %Lx!\n" 
            (Big_int_convenience.addr_to_int64 func_st); *)
          if List.length addrs > 0 then
            let st_last_instr = List.nth addrs (List.length addrs - 1) in
            (* func_end is the end of instruction; but we want the end of end, so we
            * get the next instruction func_end *)
            let _, end_last_instr = Asmir.asm_addr_to_bap p st_last_instr in
            end_last_instr
          else nan
        and
        new_callees = 
          List.filter(fun c ->
            not (List.mem c merged_fs || List.mem c t_new_new_fs)
              && Big_int_convenience.(>=%) c start
              && Big_int_convenience.(<%) c enD
          ) callees
        in
        let unique_new_callees = List.fold_left (fun l ele -> 
          if List.mem ele l then l
          else ele :: l
        ) [] new_callees in
        Printf.printf "New added start from address %Lx :"
        (Big_int_convenience.addr_to_int64 st);
        List.iter (fun a ->
          Printf.printf "%Lx " (Big_int_convenience.addr_to_int64 a)
        ) unique_new_callees;
        Printf.printf "\n%!";
        unique_new_callees @ t_new_new_fs, (st, nd) :: t_new_fb
      ) ([], []) new_fs
    
    in
    let merged_fb = old_fb @ new_fb in
    match new_new_fs with
    | [] -> 
        (* No new function start is added, merge and sort known function boundary *)
        List.fast_sort (fun (s1, _) (s2, _) ->
          Big_int_Z.compare_big_int s1 s2
        ) merged_fb
    | _ ->
        rec_extend merged_fb (merged_fs @ new_new_fs) new_new_fs

  in
  let fs_list = List.rev_map fst fb_list in
  rec_extend [] fs_list fs_list

let upgrade fb_bin_out_list =
  List.iter(fun (fb, bin, out) ->
    Printf.printf "%s --> %s\n%!" fb out;
    Printf.printf "Reading input...\n%!";
    (*aic_list : (addr * instr(string) list * addr list) list *)
    (* let aic_list = Get_input.file_to_aic iN in *)
    (*ai_list : (addr * instr(string) list) list *)
    
    let fb_list = Get_input.file_to_fb fb in
    let p = Asmir.open_program ?target:!bfd_target bin in
    let start = Asmir. get_section_startaddr p ".text" in
    let enD = Asmir. get_section_endaddr p ".text" in

    
    let time_bgn = Sys.time () in
    let upgraded_fb_list = extend fb_list p start enD in
    let time_end = Sys.time () in
    Printf.fprintf !oc_prf "test, upgrade, %s, %f\n%!" (Filename.basename bin) (time_end -.
    time_bgn);
    output_fb upgraded_fb_list out
  ) fb_bin_out_list

let main fbdir bindir fb_calldir =
  Printf.printf "Output upgrade dir: %s\n%!" fb_calldir;

  Printf.printf "Generating list....\n%!";
  let fb_bin_out_list =
    let fbfiles = 
      let a = Sys.readdir fbdir in
      List.fast_sort compare (Array.to_list a)
    in
    List.map (fun fbfile ->
      let fb = Filename.concat fbdir fbfile in
      let bin = Filename.concat bindir fbfile in
      let fb_call = Filename.concat fb_calldir fbfile in
      fb, bin, fb_call
    ) fbfiles
  in
  let update_fb_bin_out_list =
    List.filter (fun (_, _, fb_call) ->
      not (Sys.file_exists fb_call)
    ) fb_bin_out_list
  in
  
  Printf.printf "Upgrade function start....\n%!";
  upgrade update_fb_bin_out_list;
  
  close_out !oc_prf


let () = 
  let d_fb, d_bin, d_fb_call = parse_command in
  main d_fb d_bin d_fb_call

