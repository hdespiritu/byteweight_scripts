exception Argument_error
let usage = "Usage: "^Sys.argv.(0)^" -d <directory> -f <binary> -o <output model file> \
             clean one normalized signature file or a directory of normalized
             signature file. The output is a file of normalized
             signature-><times of occurence as function start>[space]<times of
             occurence as not a function start>" 

type instr = string
type input =
  | FILE of string
  | DIR of string

let instr_compare a b =
  let i_a = Str.split (Str.regexp ";") a in
  let i_b = Str.split (Str.regexp ";") b in
  let rec cmp i1 i2 = match i1, i2 with
    | _ :: _, [] -> 1
    | [], _ :: _ -> -1
    | h1 :: t1, h2 :: t2 ->
        if h1 = h2 then cmp t1 t2
        else compare h1 h2
    | [], [] -> 0
  in
  cmp i_a i_b

module Instr = struct
  type t = instr
  let equal a b = (instr_compare a b = 0)
  let hash = Hashtbl.hash

end
module InstrMap = Hashtbl.Make(Instr)


let oc = ref stdout
let file = ref ""
let dir = ref ""
let g_map = InstrMap.create 5000

let check_and_open file =
  let dir = Filename.dirname file in
  (try Unix.mkdir dir 0o755 with _ -> ());
  oc := open_out file

let speclist =
  ("-o", Arg.String(check_and_open), "write model to file")
  :: ("-f", Arg.String(fun f -> file := f), "input file")
  :: ("-d", Arg.String(fun s -> dir := s), "input directory")
  :: []

let anon_fun _ = raise (Arg.Bad usage)

let parse_command = 
  Arg.parse speclist anon_fun usage;
  if !file = "" && !dir = "" then
    raise (Arg.Bad usage)
  else if !file <> "" && !dir <> "" then
    raise (Arg.Bad usage)
  else
    if !file <> "" then FILE !file
    else DIR !dir

let rec tidy = function
  | (instr, s, n_s) :: tl ->
      let o_s, o_n_s = try InstrMap.find g_map instr with _ -> 0, 0
      in
      let u_s, u_n_s = (s + o_s), (n_s + o_n_s)
      in
      InstrMap.replace g_map instr (u_s, u_n_s);
      tidy tl
  | [] -> ()

let main_file file =
  let instr_stat = Get_input.file_to_instr_stat file in
  Printf.printf "tidy...\n%!";
  tidy instr_stat 

let main_dir dir =
  let files = Sys.readdir dir in
  let files = Array.to_list files in
  let files = List.fast_sort compare files in
  let files = List.map (Filename.concat dir) files in
  List.iter (Printf.printf "%s\n%!") files;
  List.iter main_file files

let output oc =
  let output_list =
    InstrMap.fold (fun k v l -> (k, v) :: l) g_map []
  in
  let sorted_output_list = List.fast_sort (fun (k1, _) (k2, _) ->
    instr_compare k1 k2) output_list
  in
  List.iter (fun (k, (s, n_s)) ->
    Printf.fprintf oc "%s->%d %d\n" k s n_s;
  ) sorted_output_list

let () = 
  let input = parse_command in
  (match input with
    | FILE file -> main_file file
    | DIR dir -> main_dir dir);
  output !oc;
  close_out !oc
